/* Weditres generated include file. Do NOT edit */
#define	IDD_MAINDIALOG	100
#define	ID_WINLIST	101
#define	IDUNDO		103
#define	IDSAVE		104
#define	IDREFRESH	105
