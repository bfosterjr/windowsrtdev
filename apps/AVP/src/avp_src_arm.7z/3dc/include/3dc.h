//#include <stdio.h>
//#include <stdarg.h>
//#include <stdlib.h>

#include "system.h"
#include "equates.h"
#include "platform.h"
#include "shape.h"
#include "prototyp.h"
