extern void LoadCDTrackList();
extern void CheckCDAndChooseTrackIfNeeded();
extern void ResetCDPlayForLevel();
