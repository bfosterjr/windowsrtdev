#ifndef AVP_INTRO_H
#define AVP_INTRO_H

#ifdef __cplusplus
extern "C"
{
#endif
	void PlayMenuMusic(void);
	void PlayIntroSequence(void);
	void WeWantAnIntro(void);
#ifdef __cplusplus
};
#endif

#endif
