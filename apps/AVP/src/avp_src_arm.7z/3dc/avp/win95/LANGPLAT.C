#include "3dc.h"
#include "inline.h"
#include "language.h"
/* KJL 12:07:26 05/02/97 - this will be buggered
up if the enum in gamedef.h changes */
unsigned char *LanguageFilename[] = 
{
	ENGLISH_TEXT_FILENAME,	/* I_English */ 
	ENGLISH_TEXT_FILENAME,	/* I_French  */
	ENGLISH_TEXT_FILENAME,	/* I_Spanish */ 
	ENGLISH_TEXT_FILENAME,	/* I_German  */
	ENGLISH_TEXT_FILENAME,	/* I_Italian */
	ENGLISH_TEXT_FILENAME,	/* I_Swedish */
}; 
