#define CHAR char
#define BYTE unsigned char
#define WORD unsigned short
#define DWORD unsigned int

#define SHORT short
#define VOID void