#ifndef _avpreg_h
#define _avpreg_h 1

#ifdef __cplusplus
extern "C"
{
#endif


extern char* AvpCDPath;
void GetPathFromRegistry();


#ifdef __cplusplus
};
#endif
#endif