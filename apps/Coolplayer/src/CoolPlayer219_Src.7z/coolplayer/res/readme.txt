
CoolPlayer - Blazing fast audio player.
Copyright (C) 2000-2006 Niek Albers.
Released under the GNU General Public License.

=======================================

Features:

- Skins
- Simple userinterface
- Advanced Playlist editor
- ID3 Multitagger
- File Renamer
- Fast mp3->wav converter
- Play MP3,MP3,MP1,WAV,OGG files
- Smallest executable programmed in blazing fast 'C'
- Continuous play
- 8 band equalizer
- Lot's more...

------------

Visit CoolPlayer's website at:

http://coolplayer.sourceforge.net

Visit CoolPlayer project page at:

http://sourceforge.net/projects/coolplayer