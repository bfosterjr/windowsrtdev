#include "vm_local.h"

int VM_CallCompiled( vm_t *vm, int *args ) {
	exit(99);
	return 0;
}

void VM_Compile( vm_t *vm, vmHeader_t *header ) {
	exit(99);
}
