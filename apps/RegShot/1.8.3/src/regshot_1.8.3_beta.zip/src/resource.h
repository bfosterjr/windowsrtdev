//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by regshot.rc
//
#ifndef IDC_STATIC
#define IDC_STATIC                      -1
#endif

#define IDD_DIALOG1                     100
#define IDD_DIALOG2                     101
#define IDI_MAINICON                    111
#define ID_BASE                         1000

#define IDC_1STSHOT                     1003
#define IDC_2NDSHOT                     1004
#define IDC_COMPARE                     1005
#define IDC_CLEAR1                      1006
#define IDC_CANCEL1                     1007
#define IDC_ABOUT                       1008
#define IDC_MONITOR                     1009
#define IDC_STATICSAVEFORMAT            1010
#define IDC_STATICOUTPUTPATH            1011
#define IDC_STATICADDCOMMENT            1012
#define IDC_RADIO1                      1013
#define IDC_RADIO2                      1014
#define IDC_CHECKDIR                    1015

#define IDC_STATICSERVICE               1016
#define IDC_STATICRING3                 1017
#define IDC_SETMASK                     1018
#define IDC_CHECKONTOP                  1019
#define IDC_CHECKPAUSE                  1020
#define IDC_CLEAR2                      1021
#define IDC_SAVE                        1022
#define IDC_CANCEL2                     1023
#define IDC_PBCOMPARE                   1024
#define IDC_EDITCOMMENT                 1025
#define IDC_EDITPATH                    1026
#define IDC_EDITDIR                     1027
#define IDC_TEXTCOUNT1                  1028
#define IDC_TEXTCOUNT2                  1029
#define IDC_TEXTCOUNT3                  1030
#define IDC_BROWSE1                     1031
#define IDC_BROWSE2                     1032
#define IDC_COMBOLANGUAGE               1033
#define IDC_RegOpenKey                  1034
#define IDC_RegCloseKey                 1035
#define IDC_RegCreateKey                1036
#define IDC_RegDeleteKey                1037
#define IDC_RegSetValue                 1038
#define IDC_RegSetValueEx               1039
#define IDC_RegQueryValue               1040
#define IDC_RegQueryValueEx             1041
#define IDC_RegDeleteValue              1042
#define IDC_RegEnumKey                  1043
#define IDC_RegEnumValue                1044
#define IDC_RegFlushKey                 1045
#define IDC_EDITRING3                   1046
#define IDC_LIST1                       1047
#define IDM_SHOTONLY                    1048
#define IDM_SHOTSAVE                    1049
#define IDM_LOAD                        1050
#define IDM_BREAK                       1051
#define IDM_CLEARALLSHOTS               1052
#define IDM_CLEARSHOT1                  1053
#define IDM_CLEARSHOT2                  1054

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        120
#define _APS_NEXT_COMMAND_VALUE         40007
#define _APS_NEXT_CONTROL_VALUE         1055
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
