<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>Base_Edit</name>
    <message>
        <location filename="../base_edit.cpp" line="75"/>
        <source>Select a xhtml file to edit </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="904"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="536"/>
        <source>Pleas Drag on edit modus... on View Modus is not possibel to insert items!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="677"/>
        <source>All supported Types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="692"/>
        <source>Windows Bitmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="694"/>
        <source>Graphic Interchange Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="698"/>
        <source>Joint Photographic Experts Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="700"/>
        <source>Multiple-image Network Graphics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="702"/>
        <source>Portable Network Graphics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="706"/>
        <source>Portable Bitmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="708"/>
        <source>Portable Graymap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="712"/>
        <source>X11 Bitmap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="714"/>
        <source>Icon Image File Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="718"/>
        <source>JPEG 2000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="722"/>
        <source>Tagged Image File Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="724"/>
        <source>Unknown Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="732"/>
        <source>Choose Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="742"/>
        <source>Pleas select a html supported image format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="770"/>
        <source>New Table cool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="873"/>
        <source>Cool:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="771"/>
        <source>New Table row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="857"/>
        <source>Row:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="772"/>
        <source>New Table percent on page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="772"/>
        <source>Percent %:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="857"/>
        <source>Append NR. line row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="873"/>
        <source>Tabella appendi colonne</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base_edit.cpp" line="904"/>
        <source>Unable to open file or dir  %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Edit_html</name>
    <message>
        <location filename="../edit_html.cpp" line="38"/>
        <source>Text align left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="41"/>
        <source>Text align right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="44"/>
        <source>Text align center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="476"/>
        <source>Text align Justify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="54"/>
        <source>Font Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="101"/>
        <source>Select place to export file html</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="103"/>
        <source>You Like to Tidy File? (Clean conform)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="104"/>
        <source>Pleas Confirm!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="105"/>
        <source>&amp;Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="105"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="454"/>
        <source>Open other xhtml or html file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="459"/>
        <source>Edit Modus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="461"/>
        <source>View Modus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="463"/>
        <source>Text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="464"/>
        <source>Text Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="465"/>
        <source>Text italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="466"/>
        <source>Text underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="467"/>
        <source>Link or UnLink selected Text (mailto,http)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="468"/>
        <source>Line Break</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="464"/>
        <source>Text align Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="473"/>
        <source>Text align Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="472"/>
        <source>Text align Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="487"/>
        <source>Table Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="489"/>
        <source>Insert Table here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="491"/>
        <source>Table (this) Propriety BackgroundColor, Padding, Spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="492"/>
        <source>Merge selected cell (if select)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="493"/>
        <source>Append Row on this table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="494"/>
        <source>Append Cools on this table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="495"/>
        <source>Remove this row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="496"/>
        <source>Remove this cool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="499"/>
        <source>Image edit or new </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="501"/>
        <source>Insert new image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="505"/>
        <source>Image edit &quot;%1&quot; width - height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="510"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="511"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="514"/>
        <source>&amp;Select all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="515"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="518"/>
        <source>&amp;Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="519"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="522"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="523"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="480"/>
        <source>Source View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../edit_html.cpp" line="529"/>
        <source>Close context</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="384"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="385"/>
        <source>Edit and View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="388"/>
        <source>New Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="390"/>
        <source>12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="391"/>
        <source>15</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="395"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="399"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:8pt;&quot;&gt;Font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="481"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="403"/>
        <source>Break Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="407"/>
        <source>New Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="411"/>
        <source>New Table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="413"/>
        <source>Save HTML </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="416"/>
        <source>Print File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="420"/>
        <source>Export as PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="424"/>
        <source>Export as html</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="428"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="432"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="436"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="440"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="444"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="448"/>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="452"/>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="456"/>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_edit_html.h" line="460"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Href_Gui</name>
    <message>
        <location filename="../href_gui.cpp" line="31"/>
        <source>Error Text!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_gui.cpp" line="31"/>
        <source>Mettete una url valida o un testo valido!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="145"/>
        <source>Url / www</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="146"/>
        <source>Text:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="147"/>
        <source>Url:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="148"/>
        <source>Target / Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="150"/>
        <source>_top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="151"/>
        <source>_self</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="152"/>
        <source>_blank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="153"/>
        <source>_main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="154"/>
        <source>_menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="155"/>
        <source>#name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="156"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../href_start.h" line="157"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Interface</name>
    <message>
        <location filename="../baseui.h" line="333"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="334"/>
        <source>Image info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="335"/>
        <source>Crop coordinate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="336"/>
        <source>....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="337"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="338"/>
        <source>Image manipulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="339"/>
        <source>Zoom:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="340"/>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="341"/>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="342"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="343"/>
        <source>Crop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="344"/>
        <source>Quality on Save:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="345"/>
        <source>Filter apply:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="346"/>
        <source>Color selector:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseui.h" line="347"/>
        <source>Rotate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="32"/>
        <source>Wait Sec. to PrintScreen....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="33"/>
        <source>Wait Sec. to PrintScreen....&lt;br&gt;Sec: from 1/10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="48"/>
        <source>Image minimal editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="49"/>
        <source>Save and Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="50"/>
        <source>Only save CTRL+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="325"/>
        <source>Init crop on X=%1 Y=%2  px %3x%4 CTRL + mouse to move crop area.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="327"/>
        <source>No crop action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="335"/>
        <source>Save image after rotation!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../interface.cpp" line="340"/>
        <source>Name: %1 %2x%3 / Size %4 / lastModified %5 %6</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QVimedit</name>
    <message>
        <location filename="../qvimedit.cpp" line="33"/>
        <source>Wait Sec. to PrintScreen....</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qvimedit.cpp" line="34"/>
        <source>Wait Sec. to PrintScreen....&lt;br&gt;Sec: from 1/10</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Table_Setting</name>
    <message>
        <location filename="../table_setting.cpp" line="68"/>
        <source>Table Background Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="263"/>
        <source>Table setting &amp; Propriety</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="264"/>
        <source>Table setting:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="265"/>
        <source>Border:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="266"/>
        <source>Table setting widht:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="267"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="269"/>
        <source>CellPadding:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="270"/>
        <source>Table Align:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="271"/>
        <source>CellSpacing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="272"/>
        <source>BackgroundColor:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="273"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="274"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui_table_setting.h" line="275"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
