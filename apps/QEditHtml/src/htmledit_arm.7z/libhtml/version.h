/* version information

  (c) 2006 (W3C) MIT, ERCIM, Keio University
  See tidy.h for the copyright notice.

  CVS Info :

    $Author: arnaud02 $ 
    $Date: 2006/04/13 16:27:44 $ 
    $Revision: 1.4 $ 

*/

static const char release_date[] = "13 April 2006";
