<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es_AR" sourcelanguage="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <source>:version.txt</source>
        <translation type="obsolete">:version.txt</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="20"/>
        <source>About</source>
        <translation>Acerca</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="128"/>
        <source>Translations</source>
        <translation>Traducciones</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="176"/>
        <source>Thanks to</source>
        <translation>Gracias a</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="36"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation type="obsolete">Atajos</translation>
    </message>
    <message>
        <source>&lt;p&gt;Use &lt;a href=&quot;http://code.google.com/p/qiviewer/issues/list&quot;&gt;Google code project page&lt;/a&gt; to report bugs, patches or ideas.&lt;/p&gt;
&lt;p&gt;&lt;b&gt;Aguilera Dario&lt;/b&gt;&lt;br /&gt;Developer and project founder.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;mailto:dario_21_06@hotmail.com?Subject=Hello&quot;&gt;Mail&lt;/a&gt;, 
&lt;a href=&quot;http://sammyie.wordpress.com&quot;&gt;Personal blog&lt;a&gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;Use &lt;a href=&quot;http://code.google.com/p/qiviewer/issues/list&quot;&gt;la pagina del proyecto en Google code&lt;/a&gt; para&lt;br /&gt;reportar errores, parches o ideas.&lt;/p&gt;
&lt;p&gt;&lt;b&gt;Aguilera Dario&lt;/b&gt;&lt;br /&gt;Desarrolador y fundador.&lt;/p&gt;
&lt;p&gt;&lt;a href=&quot;mailto:dario_21_06@hotmail.com?Subject=Hello&quot;&gt;Correo&lt;/a&gt;, 
&lt;a href=&quot;http://sammyie.wordpress.com&quot;&gt;Blog personal&lt;a&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A simple and lightweight image viewer, written purely in Qt.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://code.google.com/p/qiviewer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;Home page&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Un simple y ligero visor de imagenes, escrito totalmente en Qt.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;a href=&quot;http://code.google.com/p/qiviewer&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;Pagina principal&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="242"/>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>:about.txt</source>
        <translation type="obsolete">:about.txt</translation>
    </message>
    <message>
        <source>:autor.txt</source>
        <translation type="obsolete">:autor.txt</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="50"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <source>&lt;p&gt;A simple and lightweight image viewer, written purely in Qt&lt;/p&gt;
&lt;a href=&quot;http://code.google.com/p/qiviewer&quot;&gt;Home page&lt;/a&gt;</source>
        <translation type="obsolete">&lt;p&gt;Un simple y ligero visor de imagenes escrito totalmente en Qt&lt;/p&gt;
&lt;a href=&quot;http://code.google.com/p/qiviewer&quot;&gt;Home page&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="79"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <source>:license.txt</source>
        <translation type="obsolete">:license.txt</translation>
    </message>
    <message>
        <location filename="../forms/aboutdialog.ui" line="118"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="53"/>
        <source>A simple and lightweight image viewer, written totally in Qt.</source>
        <translation>Un simple y ligero visor de imagenes escrito totalmente en Qt.</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="56"/>
        <source>Home page</source>
        <translation>Paginal principal</translation>
    </message>
    <message>
        <source>Use %1 Google code project page%2 to report bugs, patches or ideas.</source>
        <translation type="obsolete">Use la %1 pagina del proyecto en Google code %2 para reportar errores, ideas y parches.</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="60"/>
        <source>Twitter account</source>
        <translation>Cuenta de Twitter</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="67"/>
        <source>Use %1Google code project page%2 to report bugs, patches or ideas.</source>
        <translation>Use la %1pagina del proyecto en Google code%2 para reportar errores, ideas y parches.</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="71"/>
        <source>Developer.</source>
        <translation>Desarrollador.</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="74"/>
        <source>Hello</source>
        <translation>Hola</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="76"/>
        <source>Email</source>
        <translation>Correo electronico</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="79"/>
        <source>Personal blog</source>
        <translation>Blog personal</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="85"/>
        <source>Icons on systems without icon themes</source>
        <translation>Iconos en sistemas sin temas de iconos</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="93"/>
        <source>Spain-spanish translation</source>
        <translation>Traducción al español de España</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="87"/>
        <source>OS/2 support</source>
        <translation>Soporte para OS/2</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="96"/>
        <source>Greek translation</source>
        <translation>Traducción al Griego</translation>
    </message>
    <message>
        <source>Action</source>
        <translation type="obsolete">Acción</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="obsolete">Atajo</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Abrir</translation>
    </message>
    <message>
        <source>Open folder</source>
        <translation type="obsolete">Abrir carpeta</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Guardar</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Salir</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation type="obsolete">Propiedades</translation>
    </message>
    <message>
        <source>Rotate to right</source>
        <translation type="obsolete">Rotar a la derecha</translation>
    </message>
    <message>
        <source>Ctrl+Shift+Right</source>
        <translation type="obsolete">Ctrl+Shift+Derecha</translation>
    </message>
    <message>
        <source>Ctrl+Shift+Left</source>
        <translation type="obsolete">Ctrl+Shift+Izquierda</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="obsolete">Derecha</translation>
    </message>
    <message>
        <source>left</source>
        <translation type="obsolete">Izquierda</translation>
    </message>
    <message>
        <source>Go to the first</source>
        <translation type="obsolete">Ir la primera</translation>
    </message>
    <message>
        <source>End</source>
        <translation type="obsolete">Fin</translation>
    </message>
    <message>
        <source>Configuration</source>
        <translation type="obsolete">Configuración</translation>
    </message>
    <message>
        <source>Show Menubar</source>
        <translation type="obsolete">Mostrar barra de menus</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Acercar</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Alejar</translation>
    </message>
    <message>
        <source>Normal Size</source>
        <translation type="obsolete">Tamaño normal</translation>
    </message>
    <message>
        <source>Adjust Size</source>
        <translation type="obsolete">Ajustar tamaño</translation>
    </message>
    <message>
        <source>Rotate to Left</source>
        <translation type="obsolete">Rotar a la izquierda</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">Siguiente</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="obsolete">Anterior</translation>
    </message>
    <message>
        <source>Home</source>
        <translation type="obsolete">Inicio</translation>
    </message>
    <message>
        <source>Go to the last</source>
        <translation type="obsolete">Ir a la ultima</translation>
    </message>
    <message>
        <source>, Personal blog</source>
        <translation type="obsolete">, Blog personal</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="46"/>
        <source>Version %1</source>
        <translation>Versión %1</translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="48"/>
        <source>Version </source>
        <translation>Versión</translation>
    </message>
</context>
<context>
    <name>ConfigDialog</name>
    <message>
        <source>Unsaved Changes</source>
        <translation type="obsolete">Cambios sin guardar</translation>
    </message>
    <message>
        <source>There are unsaved changes that you&apos;ll lose.Do you want to continue without saving them?</source>
        <translation type="obsolete">Hay cambios no guardados que vas a perder. ¿Queres continuar sin guardarlos?</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="65"/>
        <location filename="../configdialog.cpp" line="44"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <source>Tool Bar</source>
        <translation type="obsolete">Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="120"/>
        <location filename="../forms/configdialog.ui" line="711"/>
        <source>Miscellaneous</source>
        <translation>Varios</translation>
    </message>
    <message>
        <source>Adjust image to window</source>
        <translation type="obsolete">Ajustar imagen a ventana</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="138"/>
        <source>Show zoom slider</source>
        <translation>Mostrar deslizador para zoom</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="145"/>
        <source>Show menu bar</source>
        <translation>Mostrar barra de menus</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="158"/>
        <source>Compression level for saved images:</source>
        <translation>Nivel de compresión para las imagenes guardadas:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="198"/>
        <source>Recent files showed:</source>
        <translation>Archivos recientes mostrados:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="215"/>
        <source>Once you close this window, the list can&apos;t be restored</source>
        <translation>Una ves que cierres esta ventana, la lista no podrá ser restaurada</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="154"/>
        <source>This must be in the range [0,100] or -1. Specify 0 to obtain small compressed files,
100 for large uncompressed files, and -1 to use the default settings.</source>
        <translation>Debe estar en un rando de [0,100] o -1, 0 es para obtener archivos comprimidos pequenos,
100 para archivos grandes, y -1 para usar el valor por defecto.</translation>
    </message>
    <message>
        <source>Compression level for save images:</source>
        <translation type="obsolete">Nivel de compresión para guardar las imagenes:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="251"/>
        <source>Zoom increment value:</source>
        <translation>Incremento del zoom:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="288"/>
        <source>Order files by:</source>
        <translation>Ordenar archivos por:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="367"/>
        <source>Images Background</source>
        <translation>Fondo de las imagenes</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="373"/>
        <source>Alpha channel background</source>
        <translation>Fondo para canal alfa</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="383"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="391"/>
        <source>Checkered board</source>
        <translation>Tablero cuadriculado</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="396"/>
        <source>Solid color</source>
        <translation>Color solido</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="401"/>
        <source>None</source>
        <translation>Nada</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="409"/>
        <source>Color:</source>
        <translation>Color:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="423"/>
        <source>Size of the sides:</source>
        <translation>Tamaño de los lados:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="435"/>
        <source> pixels</source>
        <translation> pixels</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="475"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="518"/>
        <source>Animated Images</source>
        <translation>Imagenes animadas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="524"/>
        <source>Stop image reproduction when finish</source>
        <translation>Detener reproduccion al llegar al final</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="531"/>
        <source>Restart animation when zooming</source>
        <translation>Reiniciar animación al hacer zoom</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="733"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="783"/>
        <source>Buttom style</source>
        <translation>Estilo de los botones</translation>
    </message>
    <message>
        <source>Toolbar buttom style</source>
        <translation type="obsolete">Estilo de los botones de la barra de herramientas</translation>
    </message>
    <message>
        <source>Movie speed</source>
        <translation type="obsolete">Velocidad de reproduccion</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="258"/>
        <location filename="../forms/configdialog.ui" line="550"/>
        <source> %</source>
        <translation> %</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="540"/>
        <source>Movie&apos;s speed</source>
        <translation>Velocidad de las animaciones</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="621"/>
        <source>Use last folder</source>
        <translation>Usar ultima carpeta</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="628"/>
        <source>Use a different location:</source>
        <translation>Usar una ubicación diferente:</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="640"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Lock the tool bar position</source>
        <translation type="obsolete">Bloquear la posición de la barra de herramientas</translation>
    </message>
    <message>
        <source>Tool bar visible</source>
        <translation type="obsolete">Barra de herramientas visible</translation>
    </message>
    <message>
        <source>Tool bar position</source>
        <translation type="obsolete">Posición de la barra</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="760"/>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="753"/>
        <source>Right</source>
        <translation>Derecha</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="75"/>
        <location filename="../configdialog.cpp" line="43"/>
        <source>Toolbar</source>
        <translation>Barra de herramientas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="717"/>
        <source>Lock the toolbar position</source>
        <translation>Bloquear la posición de la barra</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="724"/>
        <source>Toolbar visible</source>
        <translation>Barra de herramientas visible</translation>
    </message>
    <message>
        <source>Toolbar position</source>
        <translation type="obsolete">Posición de la barra de herramientas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="739"/>
        <source>Top</source>
        <translation>Arriba</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="746"/>
        <source>Bottom</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <source>Tool bar buttom style</source>
        <translation type="obsolete">Estilo de los botones en la barra</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="789"/>
        <source>Only icons</source>
        <translation>Solo iconos</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="796"/>
        <source>Only text</source>
        <translation>Solo texto</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="803"/>
        <source>Text beside icons</source>
        <translation>Texto al lado de los iconos</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="810"/>
        <source>Text under icons</source>
        <translation>Texto abajo de los iconos</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="817"/>
        <source>Follow style</source>
        <translation>Seguir estilo</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="843"/>
        <source>Actions</source>
        <translation>Acciones</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="883"/>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation type="obsolete">Atajos</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="70"/>
        <location filename="../configdialog.cpp" line="45"/>
        <source>Location</source>
        <translation>Ubicación</translation>
    </message>
    <message>
        <source>ToolBar</source>
        <translation type="obsolete">Barra de
herramientas</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="893"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <source>Save changes</source>
        <translation type="obsolete">Guardar cambios</translation>
    </message>
    <message>
        <source>ok</source>
        <translation type="obsolete">Aceptar</translation>
    </message>
    <message>
        <source>Save changes and close</source>
        <translation type="obsolete">Guardar cambios y salir</translation>
    </message>
    <message>
        <location filename="../forms/configdialog.ui" line="900"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Don&apos;t save changes and close</source>
        <translation type="obsolete">No guardar los cambios y cerrar</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="79"/>
        <source>Change default location</source>
        <translation>Cambiar ubicación por defecto</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="154"/>
        <source>To configure the easter eggs, you have to execute:</source>
        <translation>Para configurar los huevos de pascua, tenes que ejecutar:</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="162"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="163"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="164"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="165"/>
        <source>Time</source>
        <translation>Hora</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="208"/>
        <source>With this you select the kind of background you want 
to use for images with alpha channel</source>
        <translation>Con esto seleccionas el tipo de fondo que queres
usar para imagenes con canal alfa</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="254"/>
        <location filename="../configdialog.cpp" line="347"/>
        <source>Delete list</source>
        <translation>Borrar lista</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="340"/>
        <source>Restore list</source>
        <translation>Restaurar lista</translation>
    </message>
    <message>
        <source>About it&apos;s changes</source>
        <translation type="obsolete">Acerca de estos cambios</translation>
    </message>
    <message>
        <source>To see the changes made here you might need to re open the image.</source>
        <translation type="obsolete">Para ver los cambios hechos aca puede que necesites abrir de nuevo la imagen.</translation>
    </message>
    <message>
        <location filename="../configdialog.cpp" line="441"/>
        <source>Select folder</source>
        <translation>Seleccionar carpeta</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../forms/edittoolbar.ui" line="90"/>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../forms/edittoolbar.ui" line="100"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../forms/edittoolbar.ui" line="107"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>EditToolBar</name>
    <message>
        <source>Configure bool bar</source>
        <translation type="obsolete">Configurar barra de herramientas</translation>
    </message>
    <message>
        <location filename="../edittoolbar.cpp" line="23"/>
        <source>Configure toolbar</source>
        <translation>Configurar barra de herramientas</translation>
    </message>
</context>
<context>
    <name>FileProperties</name>
    <message>
        <source>&lt;b&gt;Size:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Tamaño:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Height:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Alto:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Width:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Ancho:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Type:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Tipo:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Location:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Ubicación:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>&lt;b&gt;Name:&lt;/b&gt;</source>
        <translation type="obsolete">&lt;b&gt;Nombre:&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Ok</source>
        <translation type="obsolete">Aceptar</translation>
    </message>
    <message>
        <location filename="../fileproperties.cpp" line="51"/>
        <source>%1&apos;s properties</source>
        <translation>Propiedades de %1</translation>
    </message>
    <message>
        <location filename="../fileproperties.cpp" line="57"/>
        <source>%1 Image</source>
        <comment>Image type</comment>
        <translation>Imagen %1</translation>
    </message>
    <message>
        <location filename="../fileproperties.cpp" line="65"/>
        <source>%1 Bytes</source>
        <translation>%1 Bytes</translation>
    </message>
    <message>
        <location filename="../fileproperties.cpp" line="71"/>
        <source>%1 MiB (%2)</source>
        <translation>%1 MiB (%2)</translation>
    </message>
    <message>
        <location filename="../fileproperties.cpp" line="76"/>
        <source>%1 KiB (%2)</source>
        <translation>%1 KiB (%2)</translation>
    </message>
    <message>
        <source>%1 %2</source>
        <translation type="obsolete">%1 %2</translation>
    </message>
    <message>
        <source>%1 MiB</source>
        <translation type="obsolete">%1 MiB</translation>
    </message>
    <message>
        <location filename="../fileproperties.cpp" line="87"/>
        <location filename="../fileproperties.cpp" line="88"/>
        <source>%1 Pixels</source>
        <translation>%1 Pixels</translation>
    </message>
    <message>
        <source>%1 KiB</source>
        <translation type="obsolete">%1 KiB</translation>
    </message>
</context>
<context>
    <name>FileUtils</name>
    <message>
        <location filename="../fileutils.cpp" line="59"/>
        <source>Empty path, i can&apos;t do anything</source>
        <translation>Carpeta vacia, no puedo hacer nada</translation>
    </message>
    <message>
        <source>The folder is the same than the actual</source>
        <translation type="obsolete">La carpeta es la misma que la actual</translation>
    </message>
    <message>
        <location filename="../fileutils.cpp" line="30"/>
        <source>Empty file name, i can&apos;t do anything</source>
        <translation>Nombre de archivo vacio, no puedo hacer nada</translation>
    </message>
    <message>
        <location filename="../fileutils.cpp" line="68"/>
        <source>The folder is the same than the current</source>
        <translation>La carpeta es la misma que la actual</translation>
    </message>
    <message>
        <location filename="../fileutils.cpp" line="237"/>
        <source>The image wasn&apos;t moved
The new folder is iqual to the older</source>
        <translation>La imagen no fue movida
La nueva carpeta es igual a la anterior</translation>
    </message>
    <message>
        <location filename="../fileutils.cpp" line="248"/>
        <source>Overwrite?</source>
        <translation>¿Sobrescribir?</translation>
    </message>
    <message>
        <location filename="../fileutils.cpp" line="249"/>
        <source>File %1 already exists. Do you want to overwrite it?</source>
        <translation>El archivo %1 ya existe. ¿Queres sobrescribirlo?</translation>
    </message>
    <message>
        <source>No files in folder.</source>
        <translation type="obsolete">No hay archivos en la carpeta.</translation>
    </message>
</context>
<context>
    <name>Form</name>
    <message>
        <source>Miscellaneous</source>
        <translation type="obsolete">Varios</translation>
    </message>
    <message>
        <source>Adjust image to window</source>
        <translation type="obsolete">Ajustar imagen a ventana</translation>
    </message>
    <message>
        <source>Show zoom slider</source>
        <translation type="obsolete">Mostrar deslizador para zoom</translation>
    </message>
    <message>
        <source>Show menu bar</source>
        <translation type="obsolete">Mostrar barra de menus</translation>
    </message>
    <message>
        <source>This must be in the range [0,100] or -1. Specify 0 to obtain small compressed files,
100 for large uncompressed files, and -1 to use the default settings.</source>
        <translation type="obsolete">Debe estar en un rando de [0,100] o -1, 0 es para obtener archivos comprimidos pequenos,
100 para archivos grandes, y -1 para usar el valor por defecto.</translation>
    </message>
    <message>
        <source>Compression level for save images:</source>
        <translation type="obsolete">Nivel de compresión para guardar las imagenes:</translation>
    </message>
    <message>
        <source>Recent files showed:</source>
        <translation type="obsolete">Archivos recientes mostrados:</translation>
    </message>
    <message>
        <source>Once you close this window, the list can&apos;t be restored</source>
        <translation type="obsolete">Una ves que cierres esta ventana, la lista no podrá ser restaurada</translation>
    </message>
    <message>
        <source>Images Background</source>
        <translation type="obsolete">fondo de las imagenes</translation>
    </message>
    <message>
        <source>Alpha channel background</source>
        <translation type="obsolete">Fondo para canal alfa</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Tipo:</translation>
    </message>
    <message>
        <source>Checkered board</source>
        <translation type="obsolete">Tablero cuadriculado</translation>
    </message>
    <message>
        <source>Solid color</source>
        <translation type="obsolete">Color solido</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nada</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation type="obsolete">Color:</translation>
    </message>
    <message>
        <source>Size of the sides:</source>
        <translation type="obsolete">Tamaño de los lados:</translation>
    </message>
    <message>
        <source> pixels</source>
        <translation type="obsolete"> pixels</translation>
    </message>
    <message>
        <source>Animated Images</source>
        <translation type="obsolete">Imagenes animadas</translation>
    </message>
    <message>
        <source>Stop image reproduction when finish</source>
        <translation type="obsolete">Detener reproduccion al llegar al final</translation>
    </message>
    <message>
        <source>Restart animation when zooming</source>
        <translation type="obsolete">Reiniciar animación al hacer zoom</translation>
    </message>
    <message>
        <source>Movie speed</source>
        <translation type="obsolete">Velocidad de reproduccion</translation>
    </message>
    <message>
        <source> %</source>
        <translation type="obsolete"> %</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
</context>
<context>
    <name>GeneralOptionsPage</name>
    <message>
        <source>Stop image reproduction when it finish</source>
        <translation type="obsolete">Detener reproduccion al finalizar</translation>
    </message>
    <message>
        <source>This is for animated images, such as gif images</source>
        <translation type="obsolete">Esto es para imagenes animadas, tales como imagenes gif</translation>
    </message>
    <message>
        <source>Restart animation when zooming</source>
        <translation type="obsolete">Reiniciar animación al hacer zoom</translation>
    </message>
    <message>
        <source>Show zoom slider</source>
        <translation type="obsolete">Mostrar deslizador para zoom</translation>
    </message>
    <message>
        <source>Show menu bar</source>
        <translation type="obsolete">Mostrar barra de menus</translation>
    </message>
    <message>
        <source>Numbre of recent files displayed:</source>
        <translation type="obsolete">Numero de archivos recientes mostrados:</translation>
    </message>
    <message>
        <source>Checkered board</source>
        <translation type="obsolete">Tablero cuadriculado</translation>
    </message>
    <message>
        <source>Solid color</source>
        <translation type="obsolete">Color solido</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="obsolete">Tipo:</translation>
    </message>
    <message>
        <source>With this you select the kind of background you want 
to use for images with alpha channel</source>
        <translation type="obsolete">Con esto seleccionas el tipo de fondo que queres
usar para imagenes con canal alfa</translation>
    </message>
    <message>
        <source>Color:</source>
        <translation type="obsolete">Color:</translation>
    </message>
    <message>
        <source>Image&apos;s Background</source>
        <translation type="obsolete">Fondo de la imagen</translation>
    </message>
    <message>
        <source>Size of the sides:</source>
        <translation type="obsolete">Tamaño de los lados:</translation>
    </message>
    <message>
        <source>This value is the value for both height and width for each square in the chessboard background</source>
        <translation type="obsolete">Este valor es el valor de ambos largo y ancho para cada cuadrado en el fondo de tablero de ajedrez</translation>
    </message>
    <message>
        <source>Delete list</source>
        <translation type="obsolete">Borrar lista</translation>
    </message>
    <message>
        <source>Restore list</source>
        <translation type="obsolete">Restaurar lista</translation>
    </message>
    <message>
        <source>About it&apos;s changes</source>
        <translation type="obsolete">Acerca de estos cambios</translation>
    </message>
    <message>
        <source>To see the changes made here you might need to re open the image.</source>
        <translation type="obsolete">iPara ver los cambios hechos aca puede que necesites abrir de nuevo la imagen.</translation>
    </message>
    <message>
        <source>To see the changes made here applied to the images
you might need to re open it</source>
        <translation type="obsolete">Para ver algunos de los cambios realizados aca talvez
debas abrir de nuevo la imagen</translation>
    </message>
</context>
<context>
    <name>ImageWidget</name>
    <message>
        <source>animated images</source>
        <translation type="obsolete">imagenes animadas</translation>
    </message>
    <message>
        <source>vectorial images</source>
        <translation type="obsolete">imagenes vectoriales</translation>
    </message>
    <message>
        <source>QIviewer</source>
        <translation type="obsolete">QIviewer</translation>
    </message>
    <message>
        <location filename="../imagewidget.cpp" line="106"/>
        <source>I own your OS</source>
        <translation>Tu sistema me pertenece</translation>
    </message>
    <message>
        <location filename="../imagewidget.cpp" line="363"/>
        <source>PERO Q&apos; LO QUE PASOOOO!!!!</source>
        <translation>PERO Q&apos; LO QUE PASOOOO!!!!</translation>
    </message>
    <message>
        <source>I don&apos;t know how to manipulate %1 yet</source>
        <translation type="obsolete">No se manipular %1 todavia</translation>
    </message>
</context>
<context>
    <name>LocationPage</name>
    <message>
        <source>Use /home folder</source>
        <translation type="obsolete">Usar carpeta /home</translation>
    </message>
    <message>
        <source>Use last folder</source>
        <translation type="obsolete">Usar ultima carpeta</translation>
    </message>
    <message>
        <source>Use a different location:</source>
        <translation type="obsolete">Usar una ubicación diferente:</translation>
    </message>
    <message>
        <source>...</source>
        <translation type="obsolete">...</translation>
    </message>
    <message>
        <source>Change default location</source>
        <translation type="obsolete">Cambiar ubicación por defecto</translation>
    </message>
    <message>
        <source>Enter the addres that will be
used by default</source>
        <translation type="obsolete">Ingres la ubicación que será usada</translation>
    </message>
    <message>
        <source>Select folder</source>
        <translation type="obsolete">Seleccionar carpeta</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="96"/>
        <location filename="../mainwindow.cpp" line="689"/>
        <location filename="../mainwindow.cpp" line="740"/>
        <location filename="../mainwindow.cpp" line="845"/>
        <location filename="../mainwindow.cpp" line="867"/>
        <location filename="../mainwindow.cpp" line="925"/>
        <location filename="../mainwindow.cpp" line="1002"/>
        <location filename="../mainwindow.cpp" line="1046"/>
        <source>QIviewer</source>
        <translation>QIviewer</translation>
    </message>
    <message>
        <source>Zoom: %1</source>
        <translation type="obsolete">Zoom: %1</translation>
    </message>
    <message>
        <source>QIviewer couldn&apos;t open the image, what do you want
to do?</source>
        <translation type="obsolete">QIviewer no pudo abrir la imagen, ¿que queres hacer?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="274"/>
        <location filename="../mainwindow.cpp" line="523"/>
        <source>Configuration</source>
        <translation>Configuración</translation>
    </message>
    <message>
        <source>separator</source>
        <translation type="obsolete">separador</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="336"/>
        <source>&amp;Recent images</source>
        <translation>Imagenes &amp;recientes</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="353"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="359"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>&amp;Image</source>
        <translation>&amp;Imagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="373"/>
        <source>&amp;Help</source>
        <translation>A&amp;yuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="377"/>
        <source>&amp;Go</source>
        <translation>I&amp;r</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="396"/>
        <source>Main toolbar</source>
        <translation>Barra de herramientas principal</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="429"/>
        <source>&amp;Open</source>
        <translation>&amp;Abrir</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="430"/>
        <source>Open an image</source>
        <translation>Abrir una imagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="433"/>
        <source>&amp;Save</source>
        <translation>&amp;Guardar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="548"/>
        <source>Show toolbar</source>
        <translation>Mostrar barra de herramientas</translation>
    </message>
    <message>
        <source>Save</source>
        <translation type="obsolete">Guardar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="437"/>
        <source>&amp;Exit</source>
        <translation>&amp;Salir</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation type="obsolete">Salir</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="440"/>
        <source>Properties</source>
        <translation>Propiedades</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="445"/>
        <source>Zoom In</source>
        <translation>Acercar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="449"/>
        <source>Zoom Out</source>
        <translation>Alejar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="453"/>
        <source>Normal Size</source>
        <translation>Tamaño normal</translation>
    </message>
    <message>
        <source>Adjust Size</source>
        <translation type="obsolete">Ajustar tamaño</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="462"/>
        <source>Rotate to right</source>
        <translation>Rotar a la derecha</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="463"/>
        <source>Rotate image in the clockwise clock</source>
        <translation>Rota la imagene en el sentido de las agujas del reloj</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="467"/>
        <source>Rotate to Left</source>
        <translation>Rotar a la izquierda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="468"/>
        <source>Rotate image counter-clockwise to clockwise</source>
        <translation>Rota la imagen en contra del sentido de las agujas del reloj</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="472"/>
        <source>Flip vertically</source>
        <translation>Voltear verticalmente</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="473"/>
        <source>Turns vertically the image</source>
        <translation>Voltea verticalmente la imagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="477"/>
        <source>Flip horizontally</source>
        <translation>Voltear horizontalmente</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="478"/>
        <source>Reflects the image</source>
        <translation>Reflejar imagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="482"/>
        <source>A&amp;bout</source>
        <translation>A&amp;cerca</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="obsolete">Acerca</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="485"/>
        <source>About &amp;Qt</source>
        <translation>Acerca de &amp;Qt</translation>
    </message>
    <message>
        <source>About Qt</source>
        <translation type="obsolete">Acerca de Qt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="489"/>
        <source>Ne&amp;xt</source>
        <translation>&amp;Siguiente</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="490"/>
        <source>Loads next image</source>
        <translation>Carga la siguiente imagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="494"/>
        <source>Go to the first</source>
        <translation>Ir la primera</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="495"/>
        <source>Loads the first image in the folder</source>
        <translation>Carga la primer imagen en la carpeta</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <source>Pre&amp;vious</source>
        <translation>&amp;Anterior</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="500"/>
        <source>Loads previous image</source>
        <translation>Carga la imagen anterior</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="504"/>
        <source>Go to the last</source>
        <translation>Ir a la ultima</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>Loads the last image in the folder</source>
        <translation>Carga la ultima imagen en la lista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="509"/>
        <source>Open &amp;Folder</source>
        <translation>Abrir &amp;carpeta</translation>
    </message>
    <message>
        <source>Open Folder</source>
        <translation type="obsolete">Abrir carpeta</translation>
    </message>
    <message>
        <source>Look Toolbar</source>
        <translation type="obsolete">Bloquear barra de herramientas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="527"/>
        <source>Delete list</source>
        <translation>Borrar lista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="531"/>
        <source>Print</source>
        <translation>Imprimir</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="535"/>
        <location filename="../mainwindow.cpp" line="678"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="537"/>
        <source>This deletes completly the file from the disk, doesn&apos;t move it to the trash</source>
        <translation>Esto borra completamente el archivo del disco, no lo mueve a la papelera</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="540"/>
        <source>Move to...</source>
        <translation>Mover a...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="544"/>
        <source>Go to</source>
        <translation>Ir a</translation>
    </message>
    <message>
        <source>Show tool bar</source>
        <translation type="obsolete">Mostrar barra de herramientas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="553"/>
        <source>Configure toolbar</source>
        <translation>Configurar barra de herramientas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="666"/>
        <source>Move to</source>
        <translation>Mover a</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="678"/>
        <source>Do you want to delete %1?</source>
        <translation>¿Queres borrar %1?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="686"/>
        <source>File deleted</source>
        <translation>Archivo borrado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="689"/>
        <source>The file couldn&apos;t be deleted</source>
        <translation>El archivo no pudo ser borrado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="740"/>
        <source>The file doesn&apos;t exist, may be it&apos;s been moved or deleted.</source>
        <translation>El archivo no existe, talvez fue movido o borrado.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="858"/>
        <source>No folder selected</source>
        <translation>Ninguna carpeta seleccionada</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="867"/>
        <source>No folder selected, i can&apos;t do anything</source>
        <translation>Ninguna carpeta seleccionada, no hago nada</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="876"/>
        <source>I&apos;ve touched the image so, do you want to save it before exit?</source>
        <translation>¿Toque la imagen asi que, la vas a guardar antes de salir?</translation>
    </message>
    <message>
        <source>Show Menubar</source>
        <translation type="obsolete">Mostrar barra de menus</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="513"/>
        <source>Show Menu Bar</source>
        <translation>Mostrar barra de menus</translation>
    </message>
    <message>
        <source>Lock tool bar</source>
        <translation type="obsolete">Bloquera la barra de herramientas</translation>
    </message>
    <message>
        <source>Lock/unlock tool bar</source>
        <translation type="obsolete">bloquea/desbloquea la barra de herramientas</translation>
    </message>
    <message>
        <source>Get values</source>
        <translation type="obsolete">Obtener valores</translation>
    </message>
    <message>
        <source>No images in folder.</source>
        <translation type="obsolete">No hay imagenes en la carpeta.</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation type="obsolete">Ctrl+C</translation>
    </message>
    <message>
        <source>Ctrl+Shift+Right</source>
        <translation type="obsolete">Ctrl+Shift+Right</translation>
    </message>
    <message>
        <source>Ctrl+Shift+Left</source>
        <translation type="obsolete">Ctrl+Shift+Left</translation>
    </message>
    <message>
        <source>Ctrl+M</source>
        <translation type="obsolete">Ctrl+M</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="517"/>
        <source>Lock toolbar</source>
        <translation>Bloquear barra de herramientas</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="520"/>
        <source>Lock/unlock toolbar</source>
        <translation>Bloquea/desbloquea la barra de herramientas</translation>
    </message>
    <message>
        <source>Look Tool Bar</source>
        <translation type="obsolete">Bloquea/desbloquea la barra de herramientas</translation>
    </message>
    <message>
        <source>%1&apos;s properties</source>
        <translation type="obsolete">Propiedades de %1</translation>
    </message>
    <message>
        <source>The file doesn&apos;t exist, it may have been moved or deleted.</source>
        <translation type="obsolete">El archivo no existe, puede que se haya movido o borrado.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="829"/>
        <source>Save File</source>
        <translation>Guardar archivo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="831"/>
        <location filename="../mainwindow.cpp" line="916"/>
        <source>Image Files (%1)</source>
        <translation>Archivos de imagenes (%1)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="845"/>
        <source>I couldn&apos;t save the image</source>
        <translation>No pude guardar la imagen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="853"/>
        <source>Open folder</source>
        <translation>Abrir carpeta</translation>
    </message>
    <message>
        <source>Empty path, i can&apos;t do anything</source>
        <translation type="obsolete">Carpeta vacia, no puedo hacer nada</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="875"/>
        <source>Image changed</source>
        <translation>Imagen modificada</translation>
    </message>
    <message>
        <source>I&apos;ve touched the image so, do you want to save it before close it?</source>
        <translation type="obsolete">E tocado la imagen asi que, ¿queres guardarla antes de cerrarla?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="914"/>
        <source>Open file</source>
        <comment>dialog to open file</comment>
        <translation>Abrir imagen</translation>
    </message>
    <message>
        <source>I didn&apos;t find any images in the folder so, what do you want to do?</source>
        <translation type="obsolete">No encontré ninguna imagen en la carpeta, ¿que queres hacer?</translation>
    </message>
    <message>
        <source> - %1/%2</source>
        <translation type="obsolete"> - %1/%2</translation>
    </message>
    <message>
        <source> - %1</source>
        <translation type="obsolete"> - %1</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation type="obsolete">Ctrl+S</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>The image opened is vectorial, i can&apos;t handle this type yet, what do you want to do?</source>
        <translation type="obsolete">La imagen abierta es vectorial, no puedo manejar ese tipo todavia, ¿que queres hacer?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1046"/>
        <source>I couldn&apos;t make it :&apos;(</source>
        <translation>No pude hacerlo</translation>
    </message>
    <message>
        <source>Ctrl+G</source>
        <translation type="obsolete">Ctrl+G</translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation type="obsolete">Ctrl+O</translation>
    </message>
    <message>
        <source>Ctrl+Shift+O</source>
        <translation type="obsolete">Ctrl+Shift+O</translation>
    </message>
    <message>
        <source>+</source>
        <translation type="obsolete">+</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation type="obsolete">Ctrl+Q</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="obsolete">1</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation type="obsolete">Ctrl+F</translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation type="obsolete">Ctrl+H</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation type="obsolete">Ctrl+P</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="211"/>
        <location filename="../mainwindow.cpp" line="925"/>
        <source>QIviewer couldn&apos;t open the image, what do you want to do?</source>
        <translation>QIviewer no pudo abrir la imagen, ¿que queres hacer?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="457"/>
        <source>Best Fit</source>
        <translation>Ajuste optimo</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="obsolete">Anterior</translation>
    </message>
    <message>
        <source>Main tool bar</source>
        <translation type="obsolete">Barra de herramientas principal</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">Siguiente</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="obsolete">Abrir</translation>
    </message>
</context>
<context>
    <name>PrevDialog</name>
    <message>
        <source>Ok</source>
        <translation type="obsolete">Aceptar</translation>
    </message>
</context>
<context>
    <name>PropertiesDialog</name>
    <message>
        <location filename="../forms/fileproperties.ui" line="26"/>
        <source>%1&apos;s properties</source>
        <translation>Propiedades de %1</translation>
    </message>
    <message>
        <location filename="../forms/fileproperties.ui" line="44"/>
        <location filename="../forms/fileproperties.ui" line="88"/>
        <location filename="../forms/fileproperties.ui" line="116"/>
        <location filename="../forms/fileproperties.ui" line="133"/>
        <location filename="../forms/fileproperties.ui" line="150"/>
        <location filename="../forms/fileproperties.ui" line="167"/>
        <location filename="../forms/fileproperties.ui" line="184"/>
        <source>TextLabel</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../forms/fileproperties.ui" line="177"/>
        <source>&lt;b&gt;Name:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Nombre:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../forms/fileproperties.ui" line="109"/>
        <source>&lt;b&gt;Type:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Tipo:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../forms/fileproperties.ui" line="126"/>
        <source>&lt;b&gt;Size:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Tamaño:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../forms/fileproperties.ui" line="143"/>
        <source>&lt;b&gt;Height:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Alto:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../forms/fileproperties.ui" line="160"/>
        <source>&lt;b&gt;Width:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Ancho:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../forms/fileproperties.ui" line="34"/>
        <source>&lt;b&gt;Location:&lt;/b&gt;</source>
        <translation>&lt;b&gt;Ubicación:&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../forms/fileproperties.ui" line="220"/>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>How to use: qiviewer [OPTION/FILE]
Avaible options:
  -h --help         shows this help and finish
  -v --version      shows qiviewer version
  -e --eggs         shows eggs dialog
</source>
        <translation type="obsolete">Modo de uso: qiviewer [OPCIÓN/ARCHIVO]
Opciones disponibles:
  -h --help        muestra esta ayuda y finaliza
  -v --version   muestra la versión de qiviewer
  -e --eggs        muestra el dialog de los huevos
</translation>
    </message>
    <message>
        <source>How to use: qiviewer [OPTION/FILE]
Avaible options:
    %1 shows this help and finish
    %2 shows qiviewer version
    %3 shows eggs dialog
</source>
        <translation type="obsolete">Como usar: qiviewer [OPCION/ARCHIVO]
Opciones disponibles:
    %1 muestra esta ayuda y termina
    %2 muestra la version de qiviewer
    %3 muestra el dialog de los huevos de pascua
</translation>
    </message>
    <message>
        <source>Try &apos;qiviewer --help&apos; for more information
</source>
        <translation type="obsolete">Intente &apos;qiviewer --help&apos; para mas información
</translation>
    </message>
    <message>
        <source>QIviewer %1
Copyright (C) 2011 Aguilera Dario.
License GPLv2+.
&lt;http://gnu.org/licenses/gpl.html&gt;.
This is free software: you are free to change it and redistribute.
There is NO WARRANTY.
</source>
        <translation type="obsolete">QIviewer %1
Copyright (C) 2011 Aguilera Dario.
Licencia GPLv2+.
&lt;http://gnu.org/licenses/gpl.html&gt;.
Esto es software libre, eres libre de modificarlo y redistribuirlo.
No hay NINGUNA GARANTIA.
</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <source>Previous</source>
        <translation type="obsolete">Anterior</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">Siguiente</translation>
    </message>
    <message>
        <source>separator</source>
        <translation type="obsolete">separador</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Acercar</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Alejar</translation>
    </message>
    <message>
        <source>Normal Size</source>
        <translation type="obsolete">Tamaño normal</translation>
    </message>
    <message>
        <source>Best Fit</source>
        <translation type="obsolete">Ajuste optimo</translation>
    </message>
    <message>
        <source>Adjust Size</source>
        <translation type="obsolete">Ajustar tamaño</translation>
    </message>
    <message>
        <source>Rotate to Left</source>
        <translation type="obsolete">Rotar a la izquierda</translation>
    </message>
    <message>
        <source>Rotate to right</source>
        <translation type="obsolete">Rotar a la derecha</translation>
    </message>
</context>
<context>
    <name>ShortCutEditor</name>
    <message>
        <source>Action</source>
        <translation type="obsolete">Acción</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation type="obsolete">Atajo</translation>
    </message>
    <message>
        <source>Change shortcut</source>
        <translation type="obsolete">Cambiar atajo</translation>
    </message>
</context>
<context>
    <name>ToolBarEdit</name>
    <message>
        <location filename="../toolbaredit.cpp" line="29"/>
        <source>Separator</source>
        <translation>Separador</translation>
    </message>
    <message>
        <source>Add action</source>
        <translation type="obsolete">Agregar acción</translation>
    </message>
    <message>
        <source>Remove action</source>
        <translation type="obsolete">Quitar acción</translation>
    </message>
    <message>
        <source>Move action up</source>
        <translation type="obsolete">Mover arriba</translation>
    </message>
    <message>
        <source>Move action down</source>
        <translation type="obsolete">Mover abajo</translation>
    </message>
    <message>
        <location filename="../toolbaredit.cpp" line="175"/>
        <source>Add separator</source>
        <translation>Agregar separador</translation>
    </message>
    <message>
        <source>separator</source>
        <translation type="obsolete">separador</translation>
    </message>
    <message>
        <location filename="../toolbaredit.cpp" line="179"/>
        <source>Remove separator</source>
        <translation>Quitar separador</translation>
    </message>
</context>
<context>
    <name>ToolBarForm</name>
    <message>
        <source>Miscellaneous</source>
        <translation type="obsolete">Varios</translation>
    </message>
    <message>
        <source>Lock the tool bar position</source>
        <translation type="obsolete">Bloquear la posición de la barra de herramientas</translation>
    </message>
    <message>
        <source>Tool bar visible</source>
        <translation type="obsolete">Barra de herramientas visible</translation>
    </message>
    <message>
        <source>Tool bar position</source>
        <translation type="obsolete">Posición de la barra</translation>
    </message>
    <message>
        <source>Left</source>
        <translation type="obsolete">Izquierda</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="obsolete">Derecha</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="obsolete">Arriba</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="obsolete">Abajo</translation>
    </message>
    <message>
        <source>Tool bar buttom style</source>
        <translation type="obsolete">Estilo de los botones en la barra</translation>
    </message>
    <message>
        <source>Only icons</source>
        <translation type="obsolete">Solo iconos</translation>
    </message>
    <message>
        <source>Only text</source>
        <translation type="obsolete">Solo texto</translation>
    </message>
    <message>
        <source>Text beside icons</source>
        <translation type="obsolete">Texto al lado de los iconos</translation>
    </message>
    <message>
        <source>Text under icons</source>
        <translation type="obsolete">Texto abajo de los iconos</translation>
    </message>
    <message>
        <source>Follow style</source>
        <translation type="obsolete">Seguir estilo</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="obsolete">Acciones</translation>
    </message>
</context>
<context>
    <name>ToolBarPage</name>
    <message>
        <source>Left</source>
        <translation type="obsolete">Izquierda</translation>
    </message>
    <message>
        <source>Right</source>
        <translation type="obsolete">Derecha</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="obsolete">Arriba</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="obsolete">Abajo</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="obsolete">Posición</translation>
    </message>
    <message>
        <source>Lock the toolbar position</source>
        <translation type="obsolete">Bloquear la posición de la barra</translation>
    </message>
    <message>
        <source>With this you lock/unlock the tool bar</source>
        <translation type="obsolete">Con esto bloqueas/desbloqueas la barra de herramientas</translation>
    </message>
    <message>
        <source>Showed options</source>
        <translation type="obsolete">Acciones mostradas</translation>
    </message>
    <message>
        <source>Only icons</source>
        <translation type="obsolete">Solo iconos</translation>
    </message>
    <message>
        <source>Only text</source>
        <translation type="obsolete">Solo texto</translation>
    </message>
    <message>
        <source>Text beside icons</source>
        <translation type="obsolete">Texto al lado de los iconos</translation>
    </message>
    <message>
        <source>Text under icons</source>
        <translation type="obsolete">Texto abajo de los iconos</translation>
    </message>
    <message>
        <source>Follow style</source>
        <translation type="obsolete">Seguir estilo</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Estilo</translation>
    </message>
    <message>
        <source>Position and Style</source>
        <translation type="obsolete">Posición y estilo</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation type="obsolete">Acciones</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation type="obsolete">Anterior</translation>
    </message>
    <message>
        <source>Next</source>
        <translation type="obsolete">Siguiente</translation>
    </message>
    <message>
        <source>separator</source>
        <translation type="obsolete">separador</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation type="obsolete">Acercar</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation type="obsolete">Alejar</translation>
    </message>
    <message>
        <source>Normal Size</source>
        <translation type="obsolete">Tamaño normal</translation>
    </message>
    <message>
        <source>Adjust Size</source>
        <translation type="obsolete">Ajustar tamaño</translation>
    </message>
    <message>
        <source>Rotate to Left</source>
        <translation type="obsolete">Rotar a la izquierda</translation>
    </message>
    <message>
        <source>Rotate to right</source>
        <translation type="obsolete">Rotar a la derecha</translation>
    </message>
</context>
<context>
    <name>WebpDecoder</name>
    <message>
        <location filename="../webpdecoder.cpp" line="65"/>
        <source>[WEBP]in file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webpdecoder.cpp" line="71"/>
        <source>[WEBP]missing input file!!
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webpdecoder.cpp" line="83"/>
        <source>[WEBP]cannot open input file &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webpdecoder.cpp" line="104"/>
        <source>[WEBP]Decoding of %1 failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webpdecoder.cpp" line="108"/>
        <source>[WEBP]Decoded %1. Dimensions: %2 x %3. Now opening...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webpdecoder.cpp" line="113"/>
        <source>[WEBP]File %1 opened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webpdecoder.cpp" line="115"/>
        <source>[WEBP]Error opening file %s !!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZoomWidget</name>
    <message>
        <source>The zoom value isn&apos;t inside the zoom value limits</source>
        <translation type="obsolete">El valor de zoom no esta dentro de los limites</translation>
    </message>
</context>
<context>
    <name>eggsDialog</name>
    <message>
        <location filename="../forms/eggsdialog.ui" line="25"/>
        <source>Enable eggs</source>
        <translation>Habilitar huevos</translation>
    </message>
    <message>
        <location filename="../forms/eggsdialog.ui" line="42"/>
        <source>Enable binary notation</source>
        <translation>Habilitar notacion binaria</translation>
    </message>
    <message>
        <location filename="../forms/eggsdialog.ui" line="59"/>
        <source>Enable image jokes</source>
        <translation>Habilitar bromas de imagenes</translation>
    </message>
    <message>
        <location filename="../forms/eggsdialog.ui" line="76"/>
        <source>Begin</source>
        <translation>Comienzo</translation>
    </message>
    <message>
        <location filename="../forms/eggsdialog.ui" line="86"/>
        <source>End</source>
        <translation>Fin</translation>
    </message>
    <message>
        <location filename="../forms/eggsdialog.ui" line="113"/>
        <source>Ok</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../forms/eggsdialog.ui" line="120"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>goToDialog</name>
    <message>
        <location filename="../forms/gotodialog.ui" line="22"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../forms/gotodialog.ui" line="32"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../forms/gotodialog.ui" line="50"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../forms/gotodialog.ui" line="57"/>
        <source>Go</source>
        <translation>Ir</translation>
    </message>
</context>
<context>
    <name>scedialog</name>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Aplicar</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Cancelar</translation>
    </message>
</context>
<context>
    <name>toolBarEdit</name>
    <message>
        <source>Avaible actions:</source>
        <translation type="obsolete">Acciones disponibles:</translation>
    </message>
    <message>
        <location filename="../forms/toolbaredit.ui" line="22"/>
        <source>Available actions:</source>
        <translation>Acciones disponibles:</translation>
    </message>
    <message>
        <location filename="../forms/toolbaredit.ui" line="29"/>
        <location filename="../forms/toolbaredit.ui" line="168"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../forms/toolbaredit.ui" line="74"/>
        <location filename="../forms/toolbaredit.ui" line="77"/>
        <source>Move action up</source>
        <translation>Mover arriba</translation>
    </message>
    <message>
        <location filename="../forms/toolbaredit.ui" line="87"/>
        <location filename="../forms/toolbaredit.ui" line="90"/>
        <source>Remove action</source>
        <translation>Quitar acción</translation>
    </message>
    <message>
        <location filename="../forms/toolbaredit.ui" line="100"/>
        <location filename="../forms/toolbaredit.ui" line="103"/>
        <source>Add separator</source>
        <translation>Agregar separador</translation>
    </message>
    <message>
        <location filename="../forms/toolbaredit.ui" line="116"/>
        <location filename="../forms/toolbaredit.ui" line="119"/>
        <source>Add action</source>
        <translation>Agregar acción</translation>
    </message>
    <message>
        <location filename="../forms/toolbaredit.ui" line="129"/>
        <location filename="../forms/toolbaredit.ui" line="132"/>
        <source>Move action down</source>
        <translation>Mover abajo</translation>
    </message>
    <message>
        <location filename="../forms/toolbaredit.ui" line="158"/>
        <source>Current actions:</source>
        <translation>Acciones actuales:</translation>
    </message>
    <message>
        <source>Actual actions:</source>
        <translation type="obsolete">Acciones actuales:</translation>
    </message>
</context>
</TS>
