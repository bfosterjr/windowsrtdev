//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by UserNotes.rc
//
#define IDD_OPTIONS                     101
#define IDD_COMMENT                     102
#define IDD_PROCCOMMENT                 102
#define IDD_SRVCOMMENT                  103
#define IDC_DATABASE                    1001
#define IDC_BROWSE                      1002
#define IDC_COMMENT                     1003
#define IDC_REVERT                      1004
#define IDC_CHECK1                      1005
#define IDC_MATCHCOMMANDLINE            1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
