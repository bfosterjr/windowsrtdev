//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TaskbarExtPlugin.rc
//
#define IDD_OPTIONS                     101
#define IDB_APPLICATION_BMP             102
#define IDB_APPLICATION_GO_BMP          103
#define IDB_CHART_LINE_BMP              104
#define IDB_FIND_BMP                    105
#define IDC_GRAPH_TYPE                  1001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
