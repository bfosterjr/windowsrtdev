#ifndef _PH_PHDK_H
#define _PH_PHDK_H

#pragma once

#define PHLIB_IMPORT
#define PHAPPAPI __declspec(dllimport)

#include "phgui.h"
#include "phnet.h"
#include "circbuf.h"
#include "dltmgr.h"
#include "treenew.h"
#include "graph.h"
#include "emenu.h"
#include "cpysave.h"

#include "phapppub.h"

#endif
