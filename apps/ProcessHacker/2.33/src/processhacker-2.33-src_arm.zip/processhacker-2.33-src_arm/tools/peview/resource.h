//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by peview.rc
//
#define IDR_RT_MANIFEST                 1
#define IDD_PEGENERAL                   102
#define IDD_PEIMPORTS                   103
#define IDD_PEEXPORTS                   104
#define IDD_LIBEXPORTS                  105
#define IDD_PECLR                       106
#define IDD_PEEXPORTS1                  107
#define IDD_PELOADCONFIG                107
#define IDC_TARGETMACHINE               1003
#define IDC_CHECKSUM                    1004
#define IDC_SUBSYSTEM                   1005
#define IDC_SUBSYSTEMVERSION            1006
#define IDC_CHARACTERISTICS             1007
#define IDC_LIST                        1008
#define IDC_FILEICON                    1009
#define IDC_TIMESTAMP                   1010
#define IDC_RUNTIMEVERSION              1011
#define IDC_FILE                        1011
#define IDC_FLAGS                       1012
#define IDC_COMPANYNAME                 1012
#define IDC_EDIT1                       1013
#define IDC_VERSION                     1013
#define IDC_VERSIONSTRING               1014
#define IDC_IMAGEBASE                   1015
#define IDC_NAME                        1044
#define IDC_COMPANYNAME_LINK            1279

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
