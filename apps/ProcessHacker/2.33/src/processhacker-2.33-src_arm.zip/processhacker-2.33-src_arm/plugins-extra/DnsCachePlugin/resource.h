//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DnsCachePlugin.rc
//
#define IDD_DNSVIEW                     101
#define IDR_MAIN_MENU                   111
#define IDC_LIST1                       1021
#define IDC_DNSCLEAR                    4355
#define ID_DNSENTRY_FLUSH               40004
#define ID_DNSENTRY_PROPERTIES          40005

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
