//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by OnlineChecks.rc
//
#define ID_SENDTO_SERVICE1              101
#define IDD_PROGRESS                    101
#define ID_SENDTO_SERVICE2              102
#define ID_SENDTO_SERVICE3              103
#define ID_SENDTO_SERVICE4              104
#define ID_SENDTO_SERVICE5              105
#define ID_SENDTO_SERVICE6              106
#define ID_SENDTO_SERVICE7              107
#define ID_SENDTO_SERVICE8              108
#define IDC_MESSAGE                     1002
#define IDC_PROGRESS1                   1003
#define IDC_STATUS                      1004

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           109
#endif
#endif
