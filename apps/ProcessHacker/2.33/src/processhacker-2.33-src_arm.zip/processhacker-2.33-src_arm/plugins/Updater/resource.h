//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Updater.rc
//
#define IDD_UPDATE                      101
#define IDB_SF_PNG                      108
#define IDD_OPTIONS                     109
#define IDC_MESSAGE                     1002
#define IDC_AUTOCHECKBOX                1003
#define IDC_PROGRESS                    1003
#define IDC_RELDATE                     1005
#define IDC_STATUS                      1007
#define IDC_DOWNLOAD                    1010
#define IDC_UPDATEICON                  1017
#define IDC_INFOSYSLINK                 1020

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
