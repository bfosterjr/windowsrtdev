//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ToolStatus.rc
//
#define IDR_STATUS                      101
#define IDD_OPTIONS                     102
#define IDR_MAINWND_ACCEL               103
#define IDB_SEARCH_ACTIVE               104
#define IDB_APPLICATION                 105
#define IDB_APPLICATION_GO              106
#define IDB_ARROW_REFRESH               107
#define IDB_CHART_LINE                  108
#define IDB_COG_EDIT                    109
#define IDB_CROSS                       110
#define IDB_FIND                        111
#define IDB_APPLICATION_GO_BMP          112
#define IDB_ARROW_REFRESH_BMP           113
#define IDB_CHART_LINE_BMP              114
#define IDB_COG_EDIT_BMP                115
#define IDB_CROSS_BMP                   116
#define IDB_FIND_BMP                    117
#define IDB_APPLICATION_BMP             118
#define IDB_SEARCH_ACTIVE_BMP           119
#define IDB_SEARCH_INACTIVE             120
#define IDB_SEARCH_INACTIVE_BMP         121
#define IDC_ENABLE_TOOLBAR              1001
#define IDC_ENABLE_SEARCHBOX            1002
#define IDC_RESOLVEGHOSTWINDOWS         1003
#define IDC_DISPLAYSTYLECOMBO           1004
#define IDC_DISPLAYSTYLETEXT            1005
#define IDC_ENABLE_STATUSBAR            1006
#define ID_STATUS_CPUUSAGE              40001
#define ID_STATUS_COMMITCHARGE          40002
#define ID_STATUS_PHYSICALMEMORY        40003
#define ID_STATUS_NUMBEROFPROCESSES     40004
#define ID_STATUS_NUMBEROFTHREADS       40005
#define ID_STATUS_NUMBEROFHANDLES       40006
#define ID_STATUS_IO_RO                 40007
#define ID_STATUS_IO_W                  40008
#define ID_STATUS_MAX_CPU_PROCESS       40009
#define ID_STATUS_MAX_IO_PROCESS        40010
#define ID_SEARCH                       40011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        122
#define _APS_NEXT_COMMAND_VALUE         40012
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           11010
#endif
#endif
