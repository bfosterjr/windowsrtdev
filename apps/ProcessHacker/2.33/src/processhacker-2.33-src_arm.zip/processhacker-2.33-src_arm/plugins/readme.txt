Before compiling these plugins you must have generated the
Process Hacker SDK. You can do this by running makesdk.cmd in
build/sdk.