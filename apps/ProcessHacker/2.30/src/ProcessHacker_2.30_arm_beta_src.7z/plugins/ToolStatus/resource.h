//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ToolStatus.rc
//
#define IDB_APPLICATION                 101
#define IDB_APPLICATION_GO              102
#define IDB_ARROW_REFRESH               103
#define IDB_CHART_LINE                  104
#define IDB_COG_EDIT                    105
#define IDB_FIND                        106
#define IDB_LIGHTBULB_OFF               107
#define IDR_STATUS                      108
#define IDD_OPTIONS                     109
#define IDB_CROSS                       110
#define IDR_MAINWND_ACCEL               111
#define IDC_ENABLETOOLBAR               1001
#define IDC_ENABLESTATUSBAR             1002
#define IDC_RESOLVEGHOSTWINDOWS         1003
#define IDC_DISPLAYSTYLECOMBO           1004
#define IDC_DISPLAYSTYLETEXT            1005
#define ID_STATUS_CPUUSAGE              40001
#define ID_STATUS_COMMITCHARGE          40002
#define ID_STATUS_PHYSICALMEMORY        40003
#define ID_STATUS_NUMBEROFPROCESSES     40004
#define ID_STATUS_NUMBEROFTHREADS       40005
#define ID_STATUS_NUMBEROFHANDLES       40006
#define ID_STATUS_IO_RO                 40010
#define ID_STATUS_IO_W                  40011
#define ID_STATUS_MAX_CPU_PROCESS       40014
#define ID_STATUS_MAX_IO_PROCESS        40015
#define ID_SEARCH                       40016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        112
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
