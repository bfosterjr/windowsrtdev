//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by NetworkTools.rc
//
#define ID_TOOLS_PING                   101
#define IDD_OUTPUT                      101
#define ID_TOOLS_TRACEROUTE             102
#define ID_TOOLS_WHOIS                  103
#define IDC_TEXT                        1001
#define IDC_MESSAGE                     1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
