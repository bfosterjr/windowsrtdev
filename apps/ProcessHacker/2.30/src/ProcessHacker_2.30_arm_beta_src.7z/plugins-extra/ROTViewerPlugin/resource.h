//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ROTViewerPlugin.rc
//
#define IDD_ROT                         101
#define IDD_ROTVIEW                     101
#define IDD_DIALOG1                     108
#define IDD_ENTRYVIEW                   108
#define IDR_CONTEXTMENU                 110
#define IDC_LIST1                       1021
#define IDC_NAME                        1022
#define ID_MENU_REVOKE                  40002
#define ID_MENU_PROPERTIES              40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
