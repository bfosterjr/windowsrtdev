These binaries have been signed by the ReactOS Foundation.

(Note: the 32-bit version might not be signed.)