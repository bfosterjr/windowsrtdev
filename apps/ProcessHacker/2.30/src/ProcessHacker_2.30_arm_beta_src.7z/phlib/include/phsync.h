#ifndef _PH_PHSYNC_H
#define _PH_PHSYNC_H

// This header file defines synchronization primitives not included
// in phbase.

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif
