#define inttostr uinttostr
#ifdef _MSC_VER /* use 64-bit offets */
#define inttype uintmax_t
#else /* !_MSC_VER */
#define inttype unsigned int
#endif /* _MSC_VER y/n */
#include "inttostr.c"
