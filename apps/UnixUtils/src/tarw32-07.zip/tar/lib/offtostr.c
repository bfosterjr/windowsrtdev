#define inttostr offtostr
#ifdef _MSC_VER /* use 64-bit offets */
#define inttype off64_t
#else /* !_MSC_VER */
#define inttype off_t
#endif /* _MSC_VER y/n */
#include "inttostr.c"
