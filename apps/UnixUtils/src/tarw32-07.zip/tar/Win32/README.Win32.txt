file: README.Win32.txt	2009-09-08 (prev 2008-08-10)

tar version 1.21.beta for Windows

This is a WIN32 port of the source from ftp://ftp.gnu.org/gnu/tar/ -
04/14/2008 12:38PM      2,822,777 tar-1.20.tar.gz

The basic build instruction are :-
1. Download the GNU tar source
2. Download my Win32 zip file (see link at end)
3. Load tar.dsw, and build

While tape drives are not used so frequently these days, the 'tar' utility is 
still very much in use. Many sources, and other things, are shipped from the 
unix/linux environment, as a 'tar' file, usually subsequently compressed, by 
say 'gzip', or other compression utilities ... 

I had been using a GNU WIN32 port of version 1.12, circa 2001, see GNU Win32 
port, and was very happy with it until I found a 'tar' file it would not expand 
properly. So I set about porting the 2008 1.20 source to WIN32. 

Of course, it does not do _ALL_ that it does in the *nix world, but does do 
the most important things ... that is :- 

create (-c) 
Given a folder name followed by a wild card, it will 'create' a tar archive 
of all the files in the folder, and sub-folders, and 

extract (-x) 
It expand 'tar' archives back into the original folder structure ... and, of 
course 

list (-t) 
List the files contained in the archive ... 

gzip (-z) 
In addition, it will deal with 'gzip' compressed archives, if you already have 
gzip available in the path ... 

It does not deal with 'remote' archives, and will default to a '0' user and 
group, since this information is not available from the WIN32 NTFS file system. 
But it will store and restore the date of the files. 

The porting was made somewhat easy by the fact that the source contains a number 
of header files, not present in windows, like say unistd.h, in the source, as 
unistd.in.h ... with a little manipulation these files were put to good use. 

Some specific things HAD to be written for WIN32, like 'opendir()', 'readdir()', 
etc, not present in the WIN32 runtime libraries. Some old effort had ported 
some under a MSDOS switch, and most of this still works under WIN32 ... 

And uid and gid names is a bit of a cludge. ALL user names have been set to
'user', and all group names set to 'group', as did the tar 1.12 WIN32 port!

Also the *nix command shell automatically expands wild card file names in the 
shell, presenting the found list to the program. This had to be 'emulated' in 
WIN32 ... 

I used MSVC8 (Visual Studio C++ 2005 Express Edition), and there are still LOTS 
of warnings that should be looked into. But it compiles and links without error. 
I used the /MT runtime, but think it would also compile using the /MD runtime. 

The source consisted of two projects. A libtar.lib static library, and a tar.exe 
executable, and I retained it as these two components. I started with a MSVC6 
DSW/DSP build file set, and allowed MSVC8 to convert these to its SLN/VCPROJ 
files ... 

I started with the MSVC6 DSW/DSP because I have a Perl script that does quite 
well as reading the *nix Makefile.am files, and building the resultant DSW/DSP 
file ... 

In the end the 'difference' is relatively small, consisting mainly of using 
a _MSC_VER switch to provide alternate code, as most new pieces of code have 
been placed in a winport.c file ... The biggest item was developing a hand crafted 
config.h to simulate what is done by the auotmake tools. 

These two files, together with the 'converted' *nix headers, and the build files, 
have been placed in the sub-folder called Win32 ... the actual build should 
be as simple as loading either the tar.dsw or the tar.sln file into MSVC, and 
building. 

As stated, no big effort has been made to remove the remaining 'warnings' ... but 
it should build without errors.

This version has a fix for an error issued for directories...

Geoff.
http://geoffair.net/unix/tar-01.htm
2009-09-08

EOF - README.Win32.txt
