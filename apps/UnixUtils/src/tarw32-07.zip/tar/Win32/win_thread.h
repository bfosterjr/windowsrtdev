// win_thread.h

#ifndef _win_thread_h_
#define _win_thread_h_

enum thread_options {
   THREAD_USE_SYSTEM,   // call system() from a thread
   USE_SYSTEM_DIRECT,   // call system() from main thread
   USE_CREATE_PROCESS,  // create process, and redirect inherited handles
   THREAD_USE_EXECVP    // use execvp() on a new thread
};

extern char * win_genfile_thread( char * file, char * argv[], enum thread_options type );
extern int exec_error;
extern char * pthreaderr;

#endif /* _win_thread_h_ */
/* eof - win_thread.h */
