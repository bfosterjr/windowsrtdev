// windebug.h
#ifndef _windebug_h_
#define _windebug_h_

/* global defines */
#define  VFH(a)   ( a && ( a != INVALID_HANDLE_VALUE ) )
#define  DEF_LOG_FILE   "/tmp/temptmp.txt"

/* global functions */
extern char * GetWinError( DWORD dwError );
extern char * GetWinErrorText( char * lpszBuf, DWORD dwSize, DWORD dwError );
extern char * GetLastErrorText( char * lpszBuf, DWORD dwSize );
extern void win_Create_Log_File( void );
extern HANDLE win_GetOutHandle( void );

/* REALLY ONLY FOR DEBUG - !NDEBUG */
extern char * win_get_cwd( void );
extern void print_hex( char * buf, int sz, char * msg, __int64 offset );
extern void show_arguments(int argc, char ** argv);
extern void win_debug_read( size_t status, int archive, char * buffer,
                            FILE * stdlis, int verbose_option );
extern void win_show_file_creation( char * file_name, int openflag, mode_t mode, int fd,
                                    FILE * stdlis, int verbose_option );

/* global variables */
extern DWORD dw_winLastError;

#endif // _windebug_h_
// eof - windebug.h
