
// stat-linux.h
#ifndef _stat_linux_h_
#define _stat_linux_h_

/* to add some MISSING stat defines to WIN32 */

/* from linux stat.h
#if defined(__KERNEL__) || !defined(__GLIBC__) || (__GLIBC__ < 2)
#define S_IFMT  00170000

#define S_IFSOCK 0140000
#define S_IFLNK  0120000
#define S_IFREG  0100000
#define S_IFBLK  0060000
#define S_IFDIR  0040000
#define S_IFCHR  0020000
#define S_IFIFO  0010000
#define S_ISUID  0004000
#define S_ISGID  0002000
#define S_ISVTX  0001000

#define S_ISLNK(m)	(((m) & S_IFMT) == S_IFLNK)
#define S_ISREG(m)	(((m) & S_IFMT) == S_IFREG)
#define S_ISDIR(m)	(((m) & S_IFMT) == S_IFDIR)
#define S_ISCHR(m)	(((m) & S_IFMT) == S_IFCHR)
#define S_ISBLK(m)	(((m) & S_IFMT) == S_IFBLK)
#define S_ISFIFO(m)	(((m) & S_IFMT) == S_IFIFO)
#define S_ISSOCK(m)	(((m) & S_IFMT) == S_IFSOCK)

#define S_IRWXU 00700
#define S_IRUSR 00400
#define S_IWUSR 00200
#define S_IXUSR 00100
#define S_IRWXG 00070
#define S_IRGRP 00040
#define S_IWGRP 00020
#define S_IXGRP 00010
#define S_IRWXO 00007
#define S_IROTH 00004
#define S_IWOTH 00002
#define S_IXOTH 00001
#endif
 *************************** */
// from sys/stat.h
//#define _S_IFMT         0xF000          /* file type mask */
//#define _S_IFDIR        0x4000          /* directory */
//#define _S_IFCHR        0x2000          /* character special */
//#define _S_IFIFO        0x1000          /* pipe */
//#define _S_IFREG        0x8000          /* regular */
//#define _S_IREAD        0x0100          /* read permission, owner */
//#define _S_IWRITE       0x0080          /* write permission, owner */
//#define _S_IEXEC        0x0040          /* execute/search permission, owner */

#define  S_ISLNK(m)	0
#define  S_ISREG(m)	(((m) & _S_IFMT) == _S_IFREG)
#define  S_ISDIR(m)  (((m) & _S_IFMT) == _S_IFDIR)
#define  S_ISCHR(m)	(((m) & _S_IFMT) == _S_IFCHR)
#define  S_ISBLK(m)	0
#define  S_ISFIFO(m)	(((m) & _S_IFMT) == _S_IFIFO)
#define  S_ISSOCK(m)	0

#define S_IFSOCK 0
#define S_IFLNK  0
//#define S_IFREG  0100000
#define S_IFBLK  0
//#define S_IFDIR  0040000
//#define S_IFCHR  0020000
//#define S_IFIFO  0010000
#define S_ISUID  0
#define S_ISGID  0
#define S_ISVTX  0

#define S_IRUSR _S_IREAD
#define S_IRGRP S_IRUSR
#define S_IROTH S_IRUSR

#define S_IWUSR _S_IWRITE
#define S_IWGRP S_IWUSR
#define S_IWOTH S_IWUSR

#define S_IXUSR _S_IEXEC
#define S_IXGRP S_IXUSR
#define S_IXOTH S_IXUSR
#define S_IXUGO S_IXUSR

#define S_IRWXU (_S_IREAD | _S_IWRITE | _S_IEXEC)
#define S_IRWXG S_IRWXU
#define S_IRWXO S_IRWXU

#define  S_IRWXUGO   S_IRWXU

#endif /* _stat_linux_h_ */
// eof - stat-linux.h

