
// win_gzip.h
#ifndef _win_gzip_h_
#define _win_gzip_h_

/* deal with gzipping and ungzipping */
extern void try_to_gzip_it( void );
extern int try_to_ungzip_it( int ro );

#endif // _win_gzip._h_
// eof - win_gzip.h
