#ifndef WSAERROR_H
#define WSAERROR_H

const char *WSAGetErrorText(int iError);

#endif