#include <stdlib.h>

#define MAXPATHLEN _MAX_PATH