#include <posix/sys/types.h>

/* Also include MS's types.h.  Need to use subst to */
/* to get an M: drive. */
#include "C:\Program Files (x86)\Microsoft Visual Studio 11.0\VC\include\sys\types.h"