#define EGREP_PROGRAM
#include "search.c"
