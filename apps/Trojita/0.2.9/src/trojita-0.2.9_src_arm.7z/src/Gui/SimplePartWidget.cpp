/* Copyright (C) 2006 - 2011 Jan Kundrát <jkt@gentoo.org>

   This file is part of the Trojita Qt IMAP e-mail client,
   http://trojita.flaska.net/

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or the version 3 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.
*/
#include <QFileDialog>
#include <QMessageBox>
#include <QNetworkReply>
#include <QWebFrame>

#include "SimplePartWidget.h"
#include "Imap/Model/MailboxTree.h"
#include "Imap/Network/FileDownloadManager.h"

namespace Gui {

SimplePartWidget::SimplePartWidget( QWidget* parent,
                                    Imap::Network::MsgPartNetAccessManager* manager,
                                    Imap::Mailbox::TreeItemPart* _part ):
        EmbeddedWebView( parent, manager )
{
    QUrl url;
    url.setScheme( QLatin1String("trojita-imap") );
    url.setHost( QLatin1String("msg") );
    url.setPath( _part->pathToPart() );
    load( url );

    _fileDownloadManager = new Imap::Network::FileDownloadManager( this, manager, _part );
    connect( _fileDownloadManager, SIGNAL(fileNameRequested(QString*)), this, SLOT(slotFileNameRequested(QString*)) );

    saveAction = new QAction( tr("Save..."), this );
    connect( saveAction, SIGNAL(triggered()), _fileDownloadManager, SLOT(slotDownloadNow()) );
    this->addAction( saveAction );

    setContextMenuPolicy( Qt::ActionsContextMenu );
}

void SimplePartWidget::slotFileNameRequested(QString *fileName)
{
    *fileName = QFileDialog::getSaveFileName( this, tr("Save Attachment"),
                                  *fileName, QString(),
                                  0, QFileDialog::HideNameFilterDetails
                                  );
}

void SimplePartWidget::slotTransferError( const QString& errorString )
{
    QMessageBox::critical( this, tr("Can't save attachment"),
                           tr("Unable to save the attachment. Error:\n%1").arg( errorString ) );
}

QString SimplePartWidget::quoteMe() const
{
    QString selection = selectedText();
    if ( selection.isEmpty() )
        return page()->mainFrame()->toPlainText();
    else
        return selection;
}

void SimplePartWidget::reloadContents()
{
    EmbeddedWebView::reload();
}

}

