/* Copyright (C) 2006 - 2011 Jan Kundrát <jkt@gentoo.org>

   This file is part of the Trojita Qt IMAP e-mail client,
   http://trojita.flaska.net/

   This program is free software; you can redistribute it and/or
   modify it under the terms of the GNU General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or the version 3 of the License.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; see the file COPYING.  If not, write to
   the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.
*/
#ifndef MSGLISTVIEW_H
#define MSGLISTVIEW_H

#include <QTreeView>

class QSignalMapper;

namespace Gui {

/** @short A slightly tweaked QTreeView optimized for showing a list of messages in one mailbox

The optimizations (or rather modifications) include:
- automatically expanding a whole subtree when root item is expanded
- setting up reasonable size hints for all columns
*/
class MsgListView : public QTreeView
{
    Q_OBJECT
public:
    MsgListView( QWidget* parent=0 );
    virtual ~MsgListView() {}
protected:
    virtual int sizeHintForColumn( int column ) const;
private slots:
    void slotFixSize();
    /** @short Expand all items below current root index */
    void slotExpandWholeSubtree(const QModelIndex &rootIndex);
    /** @short Update header actions for showing/hiding columns */
    void slotSectionCountChanged();
    /** @short Show/hide a corresponding column */
    void slotHeaderSectionVisibilityToggled(int section);
private:
    QSignalMapper *headerFieldsMapper;
};

}

#endif // MSGLISTVIEW_H
