#ifndef __STRING_COALESCER_H__
#define __STRING_COALESCER_H__

void Coalesce(wxString& s);

void ClearStringCoalescer();
void BenchmarkStringCoalescer();

#endif
