Windows RT port..

be advised that TLS/SFTP has been compiled out due to lack of GNUTLS building in VS2012