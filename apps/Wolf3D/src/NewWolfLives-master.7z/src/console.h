
void Con_ToggleConsole_f(void);
