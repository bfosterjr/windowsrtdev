extern void M_Dead_f(void);
extern void M_Inter_f(void);
extern void M_Victory_f(void);
extern int M_Init(void);
extern void M_Draw(void);
extern void M_Keydown(int key);
extern void M_ToggleMenu_f(void);

extern bool M_Draw3D(void);