#include <windows.h>
#include <stdio.h>
#include "WolfDef.h"
/*
	Server will analyze all AI scripts & tun them. Client(s) will only
	get position af actors & their (client'(s)) health

	Also all map stuff will be on server, except for things client(s)
	will draw i.e. walls, Pwalls & doors (doors & Pwalls code will be executed on srv)
*/

int SV_Init(void)
{


}