void R_Init(void);

void R_DrawHUD(void);
void R_UpdateScreen(void);

void R_ResetFlash(void);
void R_BonusFlash(void);
void R_DamageFlash(int damage);

extern int r_fps;
extern int r_polys;