/*
// ------------------------- * Wolfenstein In Real 3D * -------------------------
	NewWolf by DarkOne the Hacker
WebPage: http://wolfgl.narod.ru
  Forum: http://hosting.gotdotnet.ru/DarkOne/phorum/default.asp
 E-mail: DarkOne@navigators.lv
*/
// ------------------------- * My Includes * -------------------------
#include "WolfDef.h"
#include "WolfGL.h"
#include "FileIOo.h"
#include "Wl_Game.h"
#include "Wl_AI.h"
