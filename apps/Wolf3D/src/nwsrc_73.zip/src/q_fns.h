
extern char com_token[1024];

int Q_atoi (char *str);
float Q_atof (char *str);
char	*COM_Parse (char *data);

void COM_DefaultExtension(char *path, char *extension);
