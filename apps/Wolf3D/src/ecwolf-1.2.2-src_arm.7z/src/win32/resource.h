#ifndef IDC_STATIC
#define IDC_STATIC -1
#endif
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by zdoom.rc
//
#define IDC_SAVEREPORT                  8
#define IDNO2                           9
#define IDI_ICON1                       101
#define IDD_MIDASINITERROR              108
#define IDD_IWADDIALOG                  112
#define IDC_INVISIBLECURSOR             114
#define IDD_CRASHDIALOG                 122
#define IDD_DIALOG1                     124
#define IDD_DIALOG2                     125
#define IDD_DIALOG3                     127
#define IDD_DIALOG4                     128
#define IDD_SAVEEAX                     128
#define IDB_BITMAP1                     131
#define IDB_DEADGUY                     131
#define IDD_CRASHDETAILS                133
#define IDD_CRASHOVERVIEW               147
#define IDD_ERRORPANE                   148
#define IDD_NETSTARTPANE                149
#define IDC_ERRORMESSAGE                1004
#define IDQUIT                          1005
#define IDC_IWADLIST                    1006
#define IDC_DONTASKIWAD                 1007
#define IDC_SPIN1                       1010
#define IDC_SPINID1                     1010
#define IDC_CRASHINFO                   1011
#define IDC_SPINID2                     1011
#define IDC_TOOLTIP1                    1012
#define IDCE_ENVIRONMENTSIZE            1025
#define IDCS_ENVIRONMENTSIZE            1026
#define IDC_DECAYTIMESCALE              1027
#define IDC_REFLECTIONSSCALE            1028
#define IDC_REFLECTIONSDELAYSCALE       1029
#define IDC_REVERBSCALE                 1030
#define IDC_REVERBDELAYSCALE            1031
#define IDC_DECAYHFLIMIT                1032
#define IDC_ECHOTIMESCALE               1033
#define IDC_MODULATIONTIMESCALE         1034
#define IDC_DUMMY                       1035
#define IDC_NEW                         1036
#define IDC_SAVE                        1037
#define IDC_REVERT                      1038
#define IDC_CURRENTENVIRONMENT          1039
#define IDC_ID2                         1040
#define IDC_ID1                         1041
#define IDC_SHOWIDS                     1043
#define IDC_LIST3                       1047
#define IDC_ENVIRONMENTLIST             1047
#define IDC_SIZEBOX                     1048
#define IDC_EDIT1                       1049
#define IDC_NEWENVNAME                  1049
#define IDC_CRASHFILECONTENTS           1049
#define IDC_BOINGEDIT                   1049
#define IDC_EDITID1                     1050
#define IDC_EDITID2                     1051
#define IDC_HOTKEY1                     1053
#define IDC_LIST1                       1054
#define IDC_ENVLIST                     1054
#define IDC_CRASHFILES                  1054
#define IDC_SELECTALL                   1055
#define IDC_SELECTNONE                  1056
#define IDC_SAVEGROUP                   1057
#define IDC_TESTEAX                     1058
#define IDC_RICHEDIT21                  1059
#define IDC_CRASHHEADER                 1059
#define IDC_RICHEDIT22                  1061
#define IDC_PLEASETELLUS                1061
#define IDC_BUTTON2                     1062
#define IDC_CRASHDETAILS                1062
#define IDC_DEADGUYVIEWER               1063
#define IDC_BOING                       1065
#define IDC_CRASHFILESIZE               1066
#define IDC_BUTTON1                     1071
#define IDC_BOINGSTATUS                 1072
#define IDC_BOINGPROGRESS               1073
#define IDC_TAB1                        1074
#define IDC_CRASHTAB                    1074
#define IDC_RICHEDIT23                  1075
#define IDC_CRASHSUMMARY                1075
#define IDC_ERRORTEXT                   1076
#define IDC_ICONPIC                     1077
#define IDC_DIVIDERBAR                  1078
#define IDC_PROGRESS1                   1079
#define IDC_STATIC_TITLE				1082
#define IDC_STATIC_STARTUP				1083

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1084
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
