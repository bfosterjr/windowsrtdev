#ifndef __WL_TEXT_H__
#define __WL_TEXT_H__

/*
=============================================================================

							WL_TEXT DEFINITIONS

=============================================================================
*/

extern  void    HelpScreens(void);

// Returns true if a screen as displayed.
extern  bool    EndText(int exitClusterNum, int enterClusterNum=-1);

#endif
