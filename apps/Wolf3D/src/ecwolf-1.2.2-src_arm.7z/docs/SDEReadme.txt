Some of the code contained in ECWolf was taken from the Simple Doom Editor 
project.  This code is licenced under the GPL which I believe is normally 
incompatible with the license for Wolfenstein and Wolf4SDL.  Since I am the 
author of that code, I am granting special permission for it to be used in 
ECWolf and derivatives.
