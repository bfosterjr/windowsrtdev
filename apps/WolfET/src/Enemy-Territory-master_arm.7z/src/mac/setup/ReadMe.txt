Wolfenstein: Enemy Territory 2.60 installation on OSX
=====================================================

Wolfenstein Enemy Territory 2.60.pkg
contains the main game files and should be installed first

Enemy Territory PunkBuster.pkg
contains the punkbuster support files. installation is optional but highly recommended as many servers require it

Feedback and bug reports:
-------------------------

Send feedback and bug reports to <ttimo@idsoftware.com>
