/*
 * Copyright (c) 2000 Mark B. Allan. All rights reserved.
 *
 * "Chromium B.S.U." is free software; you can redistribute 
 * it and/or use it and/or modify it under the terms of the 
 * "Artistic License" 
 */
#ifndef textGeometry_h
#define textGeometry_h

void textGeometryChromium(bool fullDraw = true);
void textGeometryBSU(bool fullDraw = true);

#endif // textGeometry_h



