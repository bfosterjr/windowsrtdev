#ifndef AL_STATE_H_

#include <AL/altypes.h>

ALboolean _alGetBoolean(ALenum param);
ALint _alGetInteger(ALenum param);
ALdouble _alGetDouble(ALenum param);
ALfloat _alGetFloat(ALenum param);

#endif /* AL_STATE_H_ */
