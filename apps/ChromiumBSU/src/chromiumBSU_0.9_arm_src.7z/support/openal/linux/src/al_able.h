#ifndef AL_ABLE_H_
#define AL_ABLE_H_

#include <AL/altypes.h>

ALboolean _alIsEnabled(ALenum param);
void _alEnable(ALenum param);
void _alDisable(ALenum param);

#endif /* AL_ABLE_H_ */
