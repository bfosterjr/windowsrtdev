#ifndef AL_DISTANCE_H_
#define AL_DISTANCE_H_

#include <AL/altypes.h>

void _alDistanceScale(ALfloat value);

#endif /* AL_DISTANCE_H_ */
