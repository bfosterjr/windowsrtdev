#ifndef AL_DOPPLER_H_
#define AL_DOPPLER_H_

#include <AL/altypes.h>

void _alDopplerScale(ALfloat value);

#endif /* AL_DOPPLER_H_ */
