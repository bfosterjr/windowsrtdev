/* -*- mode: C; tab-width:8; c-basic-offset:8 -*-
 * vi:set ts=8:
 *
 * alc_error.h
 *
 * openal alc error reporting.
 *
 */
#ifndef _LAL_ALC_ERROR_H_
#define _LAL_ALC_ERROR_H_

#include "AL/alctypes.h"

void _alcSetError(ALenum param);

#endif /* _LAL_ALC_ERROR_H_ */
