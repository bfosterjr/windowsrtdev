#ifndef AL_PROPAGATION_H_
#define AL_PROPAGATION_H_

#include <AL/altypes.h>

void _alPropagationSpeed(ALfloat value);

#endif /* AL_DISTANCE_H_ */
