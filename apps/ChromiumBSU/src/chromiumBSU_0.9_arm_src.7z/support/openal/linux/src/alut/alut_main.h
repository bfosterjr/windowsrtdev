#ifndef _AL_MAIN_H_
#define _AL_MAIN_H_

void alutInit(void);

#endif

