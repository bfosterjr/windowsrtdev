/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* #undef ARCH_OBJS */

/* #undef DEBUG */
/* #undef DEBUG_BUFFER */
/* #undef DEBUG_CONFIG */
/* #undef DEBUG_CONTEXT */
/* #undef DEBUG_CONVERT */
/* #undef DEBUG_EXT */
/* #undef DEBUG_LOCK */
/* #undef DEBUG_LOOP */
/* #undef DEBUG_MATH */
/* #undef DEBUG_MAXIMUS */
/* #undef DEBUG_MEM */
/* #undef DEBUG_MIXER */
/* #undef DEBUG_SOURCE */
/* #undef DEBUG_STREAMING */
/* #undef DEBUG_STUB */
/* #undef DEBUG_QUEUE */

#define BOMB 1
/* #undef FFT */
#define PIC 1

/* #undef DMALLOC */
/* #undef DMALLOC_FUNC_CHECK */
/* #undef JLIB */

#define LAL_VERSION "0.0.4"
/* #undef PARANOID_LOCKS */
/* #undef EMPTY_LOCKS */

#define USE_POSIXTHREADS 1
#define USE_POSIXMUTEX 1
/* #undef USE_WINDOWSTHREADS */
/* #undef USE_WINDOWSMUTEX */

/* #undef NODLOPEN */
/* #undef NO_THREADS */

#define _NO_STRING_INLINES 1
#define __NO_STRING_INLINES 1
/* #undef WORDS_BIGENDIAN */

/* #undef WINDOWS_TARGET */
/* #undef SOLARIS_TARGET */
#define LINUX_TARGET 1
/* #undef BSD_TARGET */
/* #undef IRIX_TARGET */

/* #undef ALSA_SUPPORT */
/* #undef ARTS_SUPPORT */
/* #undef CAPTURE_SUPPORT */
/* #undef EMU10K1_SUPPORT */
#define NULL_SUPPORT 1
/* #undef ESD_SUPPORT */
/* #undef IRIS_SUPPORT */
#define SDL_SUPPORT 1
/* #undef DSOUND_SUPPORT */
#define WAVEOUT_SUPPORT 1
#define SMPEG_SUPPORT 1
/* #undef VORBIS_SUPPORT */
