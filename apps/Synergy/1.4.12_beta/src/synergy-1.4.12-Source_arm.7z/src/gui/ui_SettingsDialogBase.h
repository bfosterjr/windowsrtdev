/********************************************************************************
** Form generated from reading UI file 'SettingsDialogBase.ui'
**
** Created: Wed Jun 26 10:50:34 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGSDIALOGBASE_H
#define UI_SETTINGSDIALOGBASE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QFormLayout>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_SettingsDialogBase
{
public:
    QVBoxLayout *verticalLayout;
    QGroupBox *m_pGroupStart;
    QGridLayout *gridLayout;
    QCheckBox *m_pCheckBoxAutoStart;
    QCheckBox *m_pCheckBoxAutoConnect;
    QCheckBox *m_pCheckBoxAutoHide;
    QGroupBox *m_pGroupCrypto;
    QFormLayout *formLayout;
    QLabel *m_pLabel_26;
    QComboBox *m_pComboCryptoMode;
    QLabel *m_pLabel_23;
    QLineEdit *m_pLineEditCryptoPass;
    QGroupBox *m_pGroupAdvanced;
    QGridLayout *gridLayout_3;
    QLabel *m_pLabel_19;
    QLineEdit *m_pLineEditScreenName;
    QLabel *m_pLabel_20;
    QSpinBox *m_pSpinBoxPort;
    QLabel *m_pLabel_21;
    QLineEdit *m_pLineEditInterface;
    QLabel *m_pLabel_22;
    QComboBox *m_pComboProcessMode;
    QGroupBox *m_pGroupLog;
    QGridLayout *gridLayout_2;
    QLabel *m_pLabel_3;
    QComboBox *m_pComboLogLevel;
    QCheckBox *m_pCheckBoxLogToFile;
    QLineEdit *m_pLineEditLogFilename;
    QPushButton *m_pButtonBrowseLog;
    QSpacerItem *verticalSpacer;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *SettingsDialogBase)
    {
        if (SettingsDialogBase->objectName().isEmpty())
            SettingsDialogBase->setObjectName(QString::fromUtf8("SettingsDialogBase"));
        SettingsDialogBase->resize(369, 459);
        verticalLayout = new QVBoxLayout(SettingsDialogBase);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        m_pGroupStart = new QGroupBox(SettingsDialogBase);
        m_pGroupStart->setObjectName(QString::fromUtf8("m_pGroupStart"));
        gridLayout = new QGridLayout(m_pGroupStart);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        m_pCheckBoxAutoStart = new QCheckBox(m_pGroupStart);
        m_pCheckBoxAutoStart->setObjectName(QString::fromUtf8("m_pCheckBoxAutoStart"));

        gridLayout->addWidget(m_pCheckBoxAutoStart, 0, 0, 1, 1);

        m_pCheckBoxAutoConnect = new QCheckBox(m_pGroupStart);
        m_pCheckBoxAutoConnect->setObjectName(QString::fromUtf8("m_pCheckBoxAutoConnect"));

        gridLayout->addWidget(m_pCheckBoxAutoConnect, 1, 0, 1, 1);

        m_pCheckBoxAutoHide = new QCheckBox(m_pGroupStart);
        m_pCheckBoxAutoHide->setObjectName(QString::fromUtf8("m_pCheckBoxAutoHide"));

        gridLayout->addWidget(m_pCheckBoxAutoHide, 2, 0, 1, 1);


        verticalLayout->addWidget(m_pGroupStart);

        m_pGroupCrypto = new QGroupBox(SettingsDialogBase);
        m_pGroupCrypto->setObjectName(QString::fromUtf8("m_pGroupCrypto"));
        m_pGroupCrypto->setEnabled(true);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_pGroupCrypto->sizePolicy().hasHeightForWidth());
        m_pGroupCrypto->setSizePolicy(sizePolicy);
        formLayout = new QFormLayout(m_pGroupCrypto);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        m_pLabel_26 = new QLabel(m_pGroupCrypto);
        m_pLabel_26->setObjectName(QString::fromUtf8("m_pLabel_26"));
        m_pLabel_26->setMinimumSize(QSize(75, 0));

        formLayout->setWidget(0, QFormLayout::LabelRole, m_pLabel_26);

        m_pComboCryptoMode = new QComboBox(m_pGroupCrypto);
        m_pComboCryptoMode->insertItems(0, QStringList()
         << QString::fromUtf8("OFB (Output Feedback)")
         << QString::fromUtf8("CFB (Cipher Feedback)")
         << QString::fromUtf8("CTR (Counter)")
         << QString::fromUtf8("GCM (Galois/Counter)")
         << QString::fromUtf8("Disable encryption")
        );
        m_pComboCryptoMode->setObjectName(QString::fromUtf8("m_pComboCryptoMode"));

        formLayout->setWidget(0, QFormLayout::FieldRole, m_pComboCryptoMode);

        m_pLabel_23 = new QLabel(m_pGroupCrypto);
        m_pLabel_23->setObjectName(QString::fromUtf8("m_pLabel_23"));
        m_pLabel_23->setMinimumSize(QSize(75, 0));

        formLayout->setWidget(1, QFormLayout::LabelRole, m_pLabel_23);

        m_pLineEditCryptoPass = new QLineEdit(m_pGroupCrypto);
        m_pLineEditCryptoPass->setObjectName(QString::fromUtf8("m_pLineEditCryptoPass"));
        m_pLineEditCryptoPass->setEnabled(true);
        m_pLineEditCryptoPass->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(1, QFormLayout::FieldRole, m_pLineEditCryptoPass);


        verticalLayout->addWidget(m_pGroupCrypto);

        m_pGroupAdvanced = new QGroupBox(SettingsDialogBase);
        m_pGroupAdvanced->setObjectName(QString::fromUtf8("m_pGroupAdvanced"));
        gridLayout_3 = new QGridLayout(m_pGroupAdvanced);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        m_pLabel_19 = new QLabel(m_pGroupAdvanced);
        m_pLabel_19->setObjectName(QString::fromUtf8("m_pLabel_19"));
        m_pLabel_19->setMinimumSize(QSize(75, 0));

        gridLayout_3->addWidget(m_pLabel_19, 0, 0, 1, 1);

        m_pLineEditScreenName = new QLineEdit(m_pGroupAdvanced);
        m_pLineEditScreenName->setObjectName(QString::fromUtf8("m_pLineEditScreenName"));
        m_pLineEditScreenName->setEnabled(true);

        gridLayout_3->addWidget(m_pLineEditScreenName, 0, 1, 1, 1);

        m_pLabel_20 = new QLabel(m_pGroupAdvanced);
        m_pLabel_20->setObjectName(QString::fromUtf8("m_pLabel_20"));

        gridLayout_3->addWidget(m_pLabel_20, 1, 0, 1, 1);

        m_pSpinBoxPort = new QSpinBox(m_pGroupAdvanced);
        m_pSpinBoxPort->setObjectName(QString::fromUtf8("m_pSpinBoxPort"));
        m_pSpinBoxPort->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::MinimumExpanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_pSpinBoxPort->sizePolicy().hasHeightForWidth());
        m_pSpinBoxPort->setSizePolicy(sizePolicy1);
        m_pSpinBoxPort->setMaximum(65535);
        m_pSpinBoxPort->setValue(24800);

        gridLayout_3->addWidget(m_pSpinBoxPort, 1, 1, 1, 1);

        m_pLabel_21 = new QLabel(m_pGroupAdvanced);
        m_pLabel_21->setObjectName(QString::fromUtf8("m_pLabel_21"));

        gridLayout_3->addWidget(m_pLabel_21, 2, 0, 1, 1);

        m_pLineEditInterface = new QLineEdit(m_pGroupAdvanced);
        m_pLineEditInterface->setObjectName(QString::fromUtf8("m_pLineEditInterface"));
        m_pLineEditInterface->setEnabled(true);

        gridLayout_3->addWidget(m_pLineEditInterface, 2, 1, 1, 1);

        m_pLabel_22 = new QLabel(m_pGroupAdvanced);
        m_pLabel_22->setObjectName(QString::fromUtf8("m_pLabel_22"));

        gridLayout_3->addWidget(m_pLabel_22, 3, 0, 1, 1);

        m_pComboProcessMode = new QComboBox(m_pGroupAdvanced);
        m_pComboProcessMode->setObjectName(QString::fromUtf8("m_pComboProcessMode"));

        gridLayout_3->addWidget(m_pComboProcessMode, 3, 1, 1, 1);


        verticalLayout->addWidget(m_pGroupAdvanced);

        m_pGroupLog = new QGroupBox(SettingsDialogBase);
        m_pGroupLog->setObjectName(QString::fromUtf8("m_pGroupLog"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::MinimumExpanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(m_pGroupLog->sizePolicy().hasHeightForWidth());
        m_pGroupLog->setSizePolicy(sizePolicy2);
        m_pGroupLog->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignVCenter);
        m_pGroupLog->setFlat(false);
        gridLayout_2 = new QGridLayout(m_pGroupLog);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        m_pLabel_3 = new QLabel(m_pGroupLog);
        m_pLabel_3->setObjectName(QString::fromUtf8("m_pLabel_3"));
        m_pLabel_3->setMinimumSize(QSize(75, 0));

        gridLayout_2->addWidget(m_pLabel_3, 0, 0, 1, 1);

        m_pComboLogLevel = new QComboBox(m_pGroupLog);
        m_pComboLogLevel->setObjectName(QString::fromUtf8("m_pComboLogLevel"));

        gridLayout_2->addWidget(m_pComboLogLevel, 0, 1, 1, 2);

        m_pCheckBoxLogToFile = new QCheckBox(m_pGroupLog);
        m_pCheckBoxLogToFile->setObjectName(QString::fromUtf8("m_pCheckBoxLogToFile"));

        gridLayout_2->addWidget(m_pCheckBoxLogToFile, 1, 0, 1, 1);

        m_pLineEditLogFilename = new QLineEdit(m_pGroupLog);
        m_pLineEditLogFilename->setObjectName(QString::fromUtf8("m_pLineEditLogFilename"));
        m_pLineEditLogFilename->setEnabled(false);

        gridLayout_2->addWidget(m_pLineEditLogFilename, 1, 1, 1, 1);

        m_pButtonBrowseLog = new QPushButton(m_pGroupLog);
        m_pButtonBrowseLog->setObjectName(QString::fromUtf8("m_pButtonBrowseLog"));
        m_pButtonBrowseLog->setEnabled(false);

        gridLayout_2->addWidget(m_pButtonBrowseLog, 1, 2, 1, 1);


        verticalLayout->addWidget(m_pGroupLog);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        buttonBox = new QDialogButtonBox(SettingsDialogBase);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);

        verticalLayout->addWidget(buttonBox);

#ifndef QT_NO_SHORTCUT
        m_pLabel_26->setBuddy(m_pComboCryptoMode);
        m_pLabel_23->setBuddy(m_pLineEditCryptoPass);
        m_pLabel_19->setBuddy(m_pLineEditScreenName);
        m_pLabel_20->setBuddy(m_pSpinBoxPort);
        m_pLabel_21->setBuddy(m_pLineEditInterface);
        m_pLabel_22->setBuddy(m_pComboProcessMode);
        m_pLabel_3->setBuddy(m_pComboLogLevel);
#endif // QT_NO_SHORTCUT
        QWidget::setTabOrder(m_pLineEditScreenName, m_pLineEditInterface);
        QWidget::setTabOrder(m_pLineEditInterface, m_pCheckBoxAutoConnect);
        QWidget::setTabOrder(m_pCheckBoxAutoConnect, m_pComboLogLevel);
        QWidget::setTabOrder(m_pComboLogLevel, m_pCheckBoxLogToFile);
        QWidget::setTabOrder(m_pCheckBoxLogToFile, m_pLineEditLogFilename);
        QWidget::setTabOrder(m_pLineEditLogFilename, buttonBox);

        retranslateUi(SettingsDialogBase);
        QObject::connect(buttonBox, SIGNAL(accepted()), SettingsDialogBase, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), SettingsDialogBase, SLOT(reject()));

        QMetaObject::connectSlotsByName(SettingsDialogBase);
    } // setupUi

    void retranslateUi(QDialog *SettingsDialogBase)
    {
        SettingsDialogBase->setWindowTitle(QApplication::translate("SettingsDialogBase", "Settings", 0, QApplication::UnicodeUTF8));
        m_pGroupStart->setTitle(QApplication::translate("SettingsDialogBase", "&Startup", 0, QApplication::UnicodeUTF8));
        m_pCheckBoxAutoStart->setText(QApplication::translate("SettingsDialogBase", "&Start Synergy after logging in", 0, QApplication::UnicodeUTF8));
        m_pCheckBoxAutoConnect->setText(QApplication::translate("SettingsDialogBase", "&Automatically start server/client", 0, QApplication::UnicodeUTF8));
        m_pCheckBoxAutoHide->setText(QApplication::translate("SettingsDialogBase", "&Hide when server/client starts", 0, QApplication::UnicodeUTF8));
        m_pGroupCrypto->setTitle(QApplication::translate("SettingsDialogBase", "&Encryption", 0, QApplication::UnicodeUTF8));
        m_pLabel_26->setText(QApplication::translate("SettingsDialogBase", "&Mode:", 0, QApplication::UnicodeUTF8));
        m_pLabel_23->setText(QApplication::translate("SettingsDialogBase", "Pass&word:", 0, QApplication::UnicodeUTF8));
        m_pGroupAdvanced->setTitle(QApplication::translate("SettingsDialogBase", "&Advanced", 0, QApplication::UnicodeUTF8));
        m_pLabel_19->setText(QApplication::translate("SettingsDialogBase", "Sc&reen name:", 0, QApplication::UnicodeUTF8));
        m_pLabel_20->setText(QApplication::translate("SettingsDialogBase", "P&ort:", 0, QApplication::UnicodeUTF8));
        m_pLabel_21->setText(QApplication::translate("SettingsDialogBase", "&Interface:", 0, QApplication::UnicodeUTF8));
        m_pLabel_22->setText(QApplication::translate("SettingsDialogBase", "&Process mode:", 0, QApplication::UnicodeUTF8));
        m_pComboProcessMode->clear();
        m_pComboProcessMode->insertItems(0, QStringList()
         << QApplication::translate("SettingsDialogBase", "Service", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("SettingsDialogBase", "Desktop (legacy)", 0, QApplication::UnicodeUTF8)
        );
        m_pGroupLog->setTitle(QApplication::translate("SettingsDialogBase", "Logging", 0, QApplication::UnicodeUTF8));
        m_pLabel_3->setText(QApplication::translate("SettingsDialogBase", "&Logging level:", 0, QApplication::UnicodeUTF8));
        m_pComboLogLevel->clear();
        m_pComboLogLevel->insertItems(0, QStringList()
         << QApplication::translate("SettingsDialogBase", "Error", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("SettingsDialogBase", "Warning", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("SettingsDialogBase", "Note", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("SettingsDialogBase", "Info", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("SettingsDialogBase", "Debug", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("SettingsDialogBase", "Debug1", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("SettingsDialogBase", "Debug2", 0, QApplication::UnicodeUTF8)
        );
        m_pCheckBoxLogToFile->setText(QApplication::translate("SettingsDialogBase", "Log to file:", 0, QApplication::UnicodeUTF8));
        m_pButtonBrowseLog->setText(QApplication::translate("SettingsDialogBase", "Browse...", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class SettingsDialogBase: public Ui_SettingsDialogBase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGSDIALOGBASE_H
