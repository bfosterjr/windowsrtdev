/********************************************************************************
** Form generated from reading UI file 'MainWindowBase.ui'
**
** Created: Wed Jun 26 10:50:34 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOWBASE_H
#define UI_MAINWINDOWBASE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QFormLayout>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QTextEdit>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindowBase
{
public:
    QAction *m_pActionAbout;
    QAction *m_pActionQuit;
    QAction *m_pActionStartSynergy;
    QAction *m_pActionStopSynergy;
    QAction *actionShowStatus;
    QAction *m_pActionMinimize;
    QAction *m_pActionRestore;
    QAction *m_pActionSave;
    QAction *m_pActionSettings;
    QAction *m_pActionWizard;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QGroupBox *m_pGroupClient;
    QFormLayout *formLayout_3;
    QLabel *label_5;
    QLabel *m_pLabelScreenName;
    QLabel *m_pLabelServerName;
    QLineEdit *m_pLineEditHostname;
    QLabel *m_pStatusLabel;
    QGroupBox *m_pGroupLog;
    QVBoxLayout *verticalLayout;
    QTextEdit *m_pLogOutput;
    QSpacerItem *spacerItem;
    QLabel *m_pUpdateIcon;
    QLabel *m_pUpdateLabel;
    QPushButton *m_pButtonToggleStart;
    QPushButton *m_pButtonApply;
    QCheckBox *m_pElevateCheckBox;
    QGroupBox *m_pGroupServer;
    QVBoxLayout *vboxLayout;
    QFormLayout *formLayout;
    QLabel *label_2;
    QLabel *m_pLabelIpAddresses;
    QRadioButton *m_pRadioInternalConfig;
    QHBoxLayout *hboxLayout;
    QPushButton *m_pButtonConfigureServer;
    QSpacerItem *spacerItem1;
    QRadioButton *m_pRadioExternalConfig;
    QHBoxLayout *hboxLayout1;
    QLabel *m_pLabelConfigurationFile;
    QLineEdit *m_pLineEditConfigFile;
    QPushButton *m_pButtonBrowseConfigFile;

    void setupUi(QMainWindow *MainWindowBase)
    {
        if (MainWindowBase->objectName().isEmpty())
            MainWindowBase->setObjectName(QString::fromUtf8("MainWindowBase"));
        MainWindowBase->resize(600, 500);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindowBase->sizePolicy().hasHeightForWidth());
        MainWindowBase->setSizePolicy(sizePolicy);
        MainWindowBase->setMinimumSize(QSize(500, 400));
        m_pActionAbout = new QAction(MainWindowBase);
        m_pActionAbout->setObjectName(QString::fromUtf8("m_pActionAbout"));
        m_pActionQuit = new QAction(MainWindowBase);
        m_pActionQuit->setObjectName(QString::fromUtf8("m_pActionQuit"));
        m_pActionStartSynergy = new QAction(MainWindowBase);
        m_pActionStartSynergy->setObjectName(QString::fromUtf8("m_pActionStartSynergy"));
        m_pActionStopSynergy = new QAction(MainWindowBase);
        m_pActionStopSynergy->setObjectName(QString::fromUtf8("m_pActionStopSynergy"));
        m_pActionStopSynergy->setEnabled(false);
        actionShowStatus = new QAction(MainWindowBase);
        actionShowStatus->setObjectName(QString::fromUtf8("actionShowStatus"));
        m_pActionMinimize = new QAction(MainWindowBase);
        m_pActionMinimize->setObjectName(QString::fromUtf8("m_pActionMinimize"));
        m_pActionRestore = new QAction(MainWindowBase);
        m_pActionRestore->setObjectName(QString::fromUtf8("m_pActionRestore"));
        m_pActionSave = new QAction(MainWindowBase);
        m_pActionSave->setObjectName(QString::fromUtf8("m_pActionSave"));
        m_pActionSettings = new QAction(MainWindowBase);
        m_pActionSettings->setObjectName(QString::fromUtf8("m_pActionSettings"));
        m_pActionWizard = new QAction(MainWindowBase);
        m_pActionWizard->setObjectName(QString::fromUtf8("m_pActionWizard"));
        centralwidget = new QWidget(MainWindowBase);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        m_pGroupClient = new QGroupBox(centralwidget);
        m_pGroupClient->setObjectName(QString::fromUtf8("m_pGroupClient"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_pGroupClient->sizePolicy().hasHeightForWidth());
        m_pGroupClient->setSizePolicy(sizePolicy1);
        m_pGroupClient->setCheckable(true);
        m_pGroupClient->setChecked(true);
        formLayout_3 = new QFormLayout(m_pGroupClient);
        formLayout_3->setObjectName(QString::fromUtf8("formLayout_3"));
        formLayout_3->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        label_5 = new QLabel(m_pGroupClient);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        formLayout_3->setWidget(0, QFormLayout::LabelRole, label_5);

        m_pLabelScreenName = new QLabel(m_pGroupClient);
        m_pLabelScreenName->setObjectName(QString::fromUtf8("m_pLabelScreenName"));

        formLayout_3->setWidget(0, QFormLayout::FieldRole, m_pLabelScreenName);

        m_pLabelServerName = new QLabel(m_pGroupClient);
        m_pLabelServerName->setObjectName(QString::fromUtf8("m_pLabelServerName"));

        formLayout_3->setWidget(1, QFormLayout::LabelRole, m_pLabelServerName);

        m_pLineEditHostname = new QLineEdit(m_pGroupClient);
        m_pLineEditHostname->setObjectName(QString::fromUtf8("m_pLineEditHostname"));

        formLayout_3->setWidget(1, QFormLayout::FieldRole, m_pLineEditHostname);


        gridLayout->addWidget(m_pGroupClient, 2, 0, 1, 12);

        m_pStatusLabel = new QLabel(centralwidget);
        m_pStatusLabel->setObjectName(QString::fromUtf8("m_pStatusLabel"));

        gridLayout->addWidget(m_pStatusLabel, 6, 1, 1, 1);

        m_pGroupLog = new QGroupBox(centralwidget);
        m_pGroupLog->setObjectName(QString::fromUtf8("m_pGroupLog"));
        verticalLayout = new QVBoxLayout(m_pGroupLog);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        m_pLogOutput = new QTextEdit(m_pGroupLog);
        m_pLogOutput->setObjectName(QString::fromUtf8("m_pLogOutput"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(m_pLogOutput->sizePolicy().hasHeightForWidth());
        m_pLogOutput->setSizePolicy(sizePolicy2);
        QFont font;
        font.setFamily(QString::fromUtf8("Courier"));
        m_pLogOutput->setFont(font);
        m_pLogOutput->setAutoFillBackground(false);
        m_pLogOutput->setUndoRedoEnabled(false);
        m_pLogOutput->setLineWrapMode(QTextEdit::NoWrap);
        m_pLogOutput->setReadOnly(true);

        verticalLayout->addWidget(m_pLogOutput);


        gridLayout->addWidget(m_pGroupLog, 3, 0, 1, 12);

        spacerItem = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(spacerItem, 6, 5, 1, 1);

        m_pUpdateIcon = new QLabel(centralwidget);
        m_pUpdateIcon->setObjectName(QString::fromUtf8("m_pUpdateIcon"));
        m_pUpdateIcon->setPixmap(QPixmap(QString::fromUtf8(":/res/icons/16x16/warning.png")));

        gridLayout->addWidget(m_pUpdateIcon, 6, 2, 1, 1);

        m_pUpdateLabel = new QLabel(centralwidget);
        m_pUpdateLabel->setObjectName(QString::fromUtf8("m_pUpdateLabel"));
        m_pUpdateLabel->setOpenExternalLinks(true);

        gridLayout->addWidget(m_pUpdateLabel, 6, 3, 1, 1);

        m_pButtonToggleStart = new QPushButton(centralwidget);
        m_pButtonToggleStart->setObjectName(QString::fromUtf8("m_pButtonToggleStart"));

        gridLayout->addWidget(m_pButtonToggleStart, 6, 11, 1, 1);

        m_pButtonApply = new QPushButton(centralwidget);
        m_pButtonApply->setObjectName(QString::fromUtf8("m_pButtonApply"));

        gridLayout->addWidget(m_pButtonApply, 6, 10, 1, 1);

        m_pElevateCheckBox = new QCheckBox(centralwidget);
        m_pElevateCheckBox->setObjectName(QString::fromUtf8("m_pElevateCheckBox"));

        gridLayout->addWidget(m_pElevateCheckBox, 6, 9, 1, 1);

        m_pGroupServer = new QGroupBox(centralwidget);
        m_pGroupServer->setObjectName(QString::fromUtf8("m_pGroupServer"));
        sizePolicy1.setHeightForWidth(m_pGroupServer->sizePolicy().hasHeightForWidth());
        m_pGroupServer->setSizePolicy(sizePolicy1);
        m_pGroupServer->setCheckable(true);
        m_pGroupServer->setChecked(true);
        vboxLayout = new QVBoxLayout(m_pGroupServer);
        vboxLayout->setObjectName(QString::fromUtf8("vboxLayout"));
        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
        label_2 = new QLabel(m_pGroupServer);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label_2);

        m_pLabelIpAddresses = new QLabel(m_pGroupServer);
        m_pLabelIpAddresses->setObjectName(QString::fromUtf8("m_pLabelIpAddresses"));

        formLayout->setWidget(0, QFormLayout::FieldRole, m_pLabelIpAddresses);


        vboxLayout->addLayout(formLayout);

        m_pRadioInternalConfig = new QRadioButton(m_pGroupServer);
        m_pRadioInternalConfig->setObjectName(QString::fromUtf8("m_pRadioInternalConfig"));
        m_pRadioInternalConfig->setChecked(true);

        vboxLayout->addWidget(m_pRadioInternalConfig);

        hboxLayout = new QHBoxLayout();
        hboxLayout->setObjectName(QString::fromUtf8("hboxLayout"));
        m_pButtonConfigureServer = new QPushButton(m_pGroupServer);
        m_pButtonConfigureServer->setObjectName(QString::fromUtf8("m_pButtonConfigureServer"));

        hboxLayout->addWidget(m_pButtonConfigureServer);

        spacerItem1 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        hboxLayout->addItem(spacerItem1);


        vboxLayout->addLayout(hboxLayout);

        m_pRadioExternalConfig = new QRadioButton(m_pGroupServer);
        m_pRadioExternalConfig->setObjectName(QString::fromUtf8("m_pRadioExternalConfig"));

        vboxLayout->addWidget(m_pRadioExternalConfig);

        hboxLayout1 = new QHBoxLayout();
        hboxLayout1->setObjectName(QString::fromUtf8("hboxLayout1"));
        m_pLabelConfigurationFile = new QLabel(m_pGroupServer);
        m_pLabelConfigurationFile->setObjectName(QString::fromUtf8("m_pLabelConfigurationFile"));

        hboxLayout1->addWidget(m_pLabelConfigurationFile);

        m_pLineEditConfigFile = new QLineEdit(m_pGroupServer);
        m_pLineEditConfigFile->setObjectName(QString::fromUtf8("m_pLineEditConfigFile"));
        m_pLineEditConfigFile->setEnabled(false);

        hboxLayout1->addWidget(m_pLineEditConfigFile);

        m_pButtonBrowseConfigFile = new QPushButton(m_pGroupServer);
        m_pButtonBrowseConfigFile->setObjectName(QString::fromUtf8("m_pButtonBrowseConfigFile"));
        m_pButtonBrowseConfigFile->setEnabled(false);

        hboxLayout1->addWidget(m_pButtonBrowseConfigFile);


        vboxLayout->addLayout(hboxLayout1);


        gridLayout->addWidget(m_pGroupServer, 1, 0, 1, 12);

        MainWindowBase->setCentralWidget(centralwidget);
#ifndef QT_NO_SHORTCUT
        m_pLabelServerName->setBuddy(m_pLineEditHostname);
        m_pLabelConfigurationFile->setBuddy(m_pLineEditConfigFile);
#endif // QT_NO_SHORTCUT

        retranslateUi(MainWindowBase);
        QObject::connect(m_pButtonToggleStart, SIGNAL(clicked()), m_pActionStartSynergy, SLOT(trigger()));
        QObject::connect(m_pRadioExternalConfig, SIGNAL(toggled(bool)), m_pLineEditConfigFile, SLOT(setEnabled(bool)));
        QObject::connect(m_pRadioExternalConfig, SIGNAL(toggled(bool)), m_pButtonBrowseConfigFile, SLOT(setEnabled(bool)));
        QObject::connect(m_pRadioInternalConfig, SIGNAL(toggled(bool)), m_pButtonConfigureServer, SLOT(setEnabled(bool)));

        QMetaObject::connectSlotsByName(MainWindowBase);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindowBase)
    {
        MainWindowBase->setWindowTitle(QApplication::translate("MainWindowBase", "Synergy", 0, QApplication::UnicodeUTF8));
        m_pActionAbout->setText(QApplication::translate("MainWindowBase", "&About Synergy...", 0, QApplication::UnicodeUTF8));
        m_pActionQuit->setText(QApplication::translate("MainWindowBase", "&Quit", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        m_pActionQuit->setStatusTip(QApplication::translate("MainWindowBase", "Quit", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        m_pActionQuit->setShortcut(QApplication::translate("MainWindowBase", "Ctrl+Q", 0, QApplication::UnicodeUTF8));
        m_pActionStartSynergy->setText(QApplication::translate("MainWindowBase", "&Start", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        m_pActionStartSynergy->setStatusTip(QApplication::translate("MainWindowBase", "Run", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        m_pActionStartSynergy->setShortcut(QApplication::translate("MainWindowBase", "Ctrl+S", 0, QApplication::UnicodeUTF8));
        m_pActionStopSynergy->setText(QApplication::translate("MainWindowBase", "S&top", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        m_pActionStopSynergy->setStatusTip(QApplication::translate("MainWindowBase", "Stop", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        m_pActionStopSynergy->setShortcut(QApplication::translate("MainWindowBase", "Ctrl+T", 0, QApplication::UnicodeUTF8));
        actionShowStatus->setText(QApplication::translate("MainWindowBase", "S&how Status", 0, QApplication::UnicodeUTF8));
        actionShowStatus->setShortcut(QApplication::translate("MainWindowBase", "Ctrl+H", 0, QApplication::UnicodeUTF8));
        m_pActionMinimize->setText(QApplication::translate("MainWindowBase", "&Hide", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        m_pActionMinimize->setToolTip(QApplication::translate("MainWindowBase", "Hide", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        m_pActionRestore->setText(QApplication::translate("MainWindowBase", "&Show", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        m_pActionRestore->setToolTip(QApplication::translate("MainWindowBase", "Show", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        m_pActionSave->setText(QApplication::translate("MainWindowBase", "Save configuration &as...", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        m_pActionSave->setStatusTip(QApplication::translate("MainWindowBase", "Save the interactively generated server configuration to a file.", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        m_pActionSave->setShortcut(QApplication::translate("MainWindowBase", "Ctrl+Alt+S", 0, QApplication::UnicodeUTF8));
        m_pActionSettings->setText(QApplication::translate("MainWindowBase", "Settings", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_STATUSTIP
        m_pActionSettings->setStatusTip(QApplication::translate("MainWindowBase", "Edit settings", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_STATUSTIP
        m_pActionWizard->setText(QApplication::translate("MainWindowBase", "Run Wizard", 0, QApplication::UnicodeUTF8));
        m_pGroupClient->setTitle(QApplication::translate("MainWindowBase", "&Client (use another computer's keyboard and mouse):", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("MainWindowBase", "Screen name:", 0, QApplication::UnicodeUTF8));
        m_pLabelScreenName->setText(QApplication::translate("MainWindowBase", "Unknown", 0, QApplication::UnicodeUTF8));
        m_pLabelServerName->setText(QApplication::translate("MainWindowBase", "&Server IP:", 0, QApplication::UnicodeUTF8));
        m_pStatusLabel->setText(QApplication::translate("MainWindowBase", "Ready", 0, QApplication::UnicodeUTF8));
        m_pGroupLog->setTitle(QApplication::translate("MainWindowBase", "Log", 0, QApplication::UnicodeUTF8));
        m_pUpdateIcon->setText(QString());
        m_pUpdateLabel->setText(QString());
        m_pButtonToggleStart->setText(QApplication::translate("MainWindowBase", "&Start", 0, QApplication::UnicodeUTF8));
        m_pButtonApply->setText(QApplication::translate("MainWindowBase", "&Apply", 0, QApplication::UnicodeUTF8));
        m_pElevateCheckBox->setText(QApplication::translate("MainWindowBase", "&Elevate", 0, QApplication::UnicodeUTF8));
        m_pGroupServer->setTitle(QApplication::translate("MainWindowBase", "&Server (share this computer's mouse and keyboard):", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("MainWindowBase", "IP addresses:", 0, QApplication::UnicodeUTF8));
        m_pLabelIpAddresses->setText(QApplication::translate("MainWindowBase", "Unknown", 0, QApplication::UnicodeUTF8));
        m_pRadioInternalConfig->setText(QApplication::translate("MainWindowBase", "Configure interactively:", 0, QApplication::UnicodeUTF8));
        m_pButtonConfigureServer->setText(QApplication::translate("MainWindowBase", "&Configure Server...", 0, QApplication::UnicodeUTF8));
        m_pRadioExternalConfig->setText(QApplication::translate("MainWindowBase", "Use existing configuration:", 0, QApplication::UnicodeUTF8));
        m_pLabelConfigurationFile->setText(QApplication::translate("MainWindowBase", "&Configuration file:", 0, QApplication::UnicodeUTF8));
        m_pButtonBrowseConfigFile->setText(QApplication::translate("MainWindowBase", "&Browse...", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWindowBase: public Ui_MainWindowBase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOWBASE_H
