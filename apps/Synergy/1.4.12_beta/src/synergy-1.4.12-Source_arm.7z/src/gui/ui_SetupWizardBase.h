/********************************************************************************
** Form generated from reading UI file 'SetupWizardBase.ui'
**
** Created: Wed Jun 26 10:50:34 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETUPWIZARDBASE_H
#define UI_SETUPWIZARDBASE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QFormLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QRadioButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWizard>
#include <QtGui/QWizardPage>

QT_BEGIN_NAMESPACE

class Ui_SetupWizardBase
{
public:
    QWizardPage *m_pNodePage;
    QVBoxLayout *verticalLayout_2;
    QRadioButton *m_pServerRadioButton;
    QLabel *m_pClientLabel;
    QSpacerItem *verticalSpacer;
    QRadioButton *m_pClientRadioButton;
    QLabel *m_pServerLabel;
    QSpacerItem *verticalSpacer_2;
    QWizardPage *m_pCryptoPage;
    QVBoxLayout *verticalLayout;
    QLabel *label_2;
    QSpacerItem *verticalSpacer_3;
    QLabel *label;
    QFormLayout *formLayout;
    QLabel *m_pLabel_26;
    QComboBox *m_pComboCryptoMode;
    QSpacerItem *verticalSpacer_5;
    QLabel *m_pLabel_27;
    QFormLayout *formLayout_2;
    QLabel *m_pLabel_23;
    QLineEdit *m_pLineEditCryptoPass;
    QLabel *m_pLabel_24;
    QLineEdit *m_pLineEditCryptoPassConfirm;
    QSpacerItem *verticalSpacer_4;

    void setupUi(QWizard *SetupWizardBase)
    {
        if (SetupWizardBase->objectName().isEmpty())
            SetupWizardBase->setObjectName(QString::fromUtf8("SetupWizardBase"));
        SetupWizardBase->resize(500, 390);
        SetupWizardBase->setMinimumSize(QSize(500, 390));
        m_pNodePage = new QWizardPage();
        m_pNodePage->setObjectName(QString::fromUtf8("m_pNodePage"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(m_pNodePage->sizePolicy().hasHeightForWidth());
        m_pNodePage->setSizePolicy(sizePolicy);
        verticalLayout_2 = new QVBoxLayout(m_pNodePage);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        m_pServerRadioButton = new QRadioButton(m_pNodePage);
        m_pServerRadioButton->setObjectName(QString::fromUtf8("m_pServerRadioButton"));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        m_pServerRadioButton->setFont(font);

        verticalLayout_2->addWidget(m_pServerRadioButton);

        m_pClientLabel = new QLabel(m_pNodePage);
        m_pClientLabel->setObjectName(QString::fromUtf8("m_pClientLabel"));
        m_pClientLabel->setMinimumSize(QSize(0, 0));
        m_pClientLabel->setWordWrap(true);

        verticalLayout_2->addWidget(m_pClientLabel);

        verticalSpacer = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer);

        m_pClientRadioButton = new QRadioButton(m_pNodePage);
        m_pClientRadioButton->setObjectName(QString::fromUtf8("m_pClientRadioButton"));
        m_pClientRadioButton->setFont(font);

        verticalLayout_2->addWidget(m_pClientRadioButton);

        m_pServerLabel = new QLabel(m_pNodePage);
        m_pServerLabel->setObjectName(QString::fromUtf8("m_pServerLabel"));
        m_pServerLabel->setMinimumSize(QSize(0, 0));
        m_pServerLabel->setWordWrap(true);

        verticalLayout_2->addWidget(m_pServerLabel);

        verticalSpacer_2 = new QSpacerItem(0, 0, QSizePolicy::Minimum, QSizePolicy::MinimumExpanding);

        verticalLayout_2->addItem(verticalSpacer_2);

        SetupWizardBase->addPage(m_pNodePage);
        m_pCryptoPage = new QWizardPage();
        m_pCryptoPage->setObjectName(QString::fromUtf8("m_pCryptoPage"));
        sizePolicy.setHeightForWidth(m_pCryptoPage->sizePolicy().hasHeightForWidth());
        m_pCryptoPage->setSizePolicy(sizePolicy);
        verticalLayout = new QVBoxLayout(m_pCryptoPage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label_2 = new QLabel(m_pCryptoPage);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setWordWrap(true);

        verticalLayout->addWidget(label_2);

        verticalSpacer_3 = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_3);

        label = new QLabel(m_pCryptoPage);
        label->setObjectName(QString::fromUtf8("label"));
        label->setWordWrap(true);

        verticalLayout->addWidget(label);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setFieldGrowthPolicy(QFormLayout::ExpandingFieldsGrow);
        m_pLabel_26 = new QLabel(m_pCryptoPage);
        m_pLabel_26->setObjectName(QString::fromUtf8("m_pLabel_26"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(m_pLabel_26->sizePolicy().hasHeightForWidth());
        m_pLabel_26->setSizePolicy(sizePolicy1);
        m_pLabel_26->setMinimumSize(QSize(100, 0));
        m_pLabel_26->setSizeIncrement(QSize(0, 0));
        m_pLabel_26->setBaseSize(QSize(0, 0));
        m_pLabel_26->setFont(font);
        m_pLabel_26->setIndent(10);

        formLayout->setWidget(1, QFormLayout::LabelRole, m_pLabel_26);

        m_pComboCryptoMode = new QComboBox(m_pCryptoPage);
        m_pComboCryptoMode->insertItems(0, QStringList()
         << QString::fromUtf8("")
         << QString::fromUtf8("OFB (Output Feedback)")
         << QString::fromUtf8("CFB (Cipher Feedback)")
         << QString::fromUtf8("CTR (Counter)")
         << QString::fromUtf8("GCM (Galois/Counter)")
         << QString::fromUtf8("Disable encryption")
        );
        m_pComboCryptoMode->setObjectName(QString::fromUtf8("m_pComboCryptoMode"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(m_pComboCryptoMode->sizePolicy().hasHeightForWidth());
        m_pComboCryptoMode->setSizePolicy(sizePolicy2);
        m_pComboCryptoMode->setMinimumSize(QSize(200, 0));

        formLayout->setWidget(1, QFormLayout::FieldRole, m_pComboCryptoMode);


        verticalLayout->addLayout(formLayout);

        verticalSpacer_5 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout->addItem(verticalSpacer_5);

        m_pLabel_27 = new QLabel(m_pCryptoPage);
        m_pLabel_27->setObjectName(QString::fromUtf8("m_pLabel_27"));
        m_pLabel_27->setMinimumSize(QSize(0, 0));
        m_pLabel_27->setWordWrap(true);

        verticalLayout->addWidget(m_pLabel_27);

        formLayout_2 = new QFormLayout();
        formLayout_2->setObjectName(QString::fromUtf8("formLayout_2"));
        m_pLabel_23 = new QLabel(m_pCryptoPage);
        m_pLabel_23->setObjectName(QString::fromUtf8("m_pLabel_23"));
        m_pLabel_23->setMinimumSize(QSize(100, 0));
        m_pLabel_23->setFont(font);
        m_pLabel_23->setIndent(10);

        formLayout_2->setWidget(1, QFormLayout::LabelRole, m_pLabel_23);

        m_pLineEditCryptoPass = new QLineEdit(m_pCryptoPage);
        m_pLineEditCryptoPass->setObjectName(QString::fromUtf8("m_pLineEditCryptoPass"));
        m_pLineEditCryptoPass->setEnabled(true);
        sizePolicy2.setHeightForWidth(m_pLineEditCryptoPass->sizePolicy().hasHeightForWidth());
        m_pLineEditCryptoPass->setSizePolicy(sizePolicy2);
        m_pLineEditCryptoPass->setMinimumSize(QSize(200, 0));
        m_pLineEditCryptoPass->setSizeIncrement(QSize(0, 0));
        m_pLineEditCryptoPass->setBaseSize(QSize(0, 0));
        m_pLineEditCryptoPass->setEchoMode(QLineEdit::Password);

        formLayout_2->setWidget(1, QFormLayout::FieldRole, m_pLineEditCryptoPass);

        m_pLabel_24 = new QLabel(m_pCryptoPage);
        m_pLabel_24->setObjectName(QString::fromUtf8("m_pLabel_24"));
        m_pLabel_24->setMinimumSize(QSize(100, 0));
        m_pLabel_24->setFont(font);
        m_pLabel_24->setIndent(10);

        formLayout_2->setWidget(2, QFormLayout::LabelRole, m_pLabel_24);

        m_pLineEditCryptoPassConfirm = new QLineEdit(m_pCryptoPage);
        m_pLineEditCryptoPassConfirm->setObjectName(QString::fromUtf8("m_pLineEditCryptoPassConfirm"));
        m_pLineEditCryptoPassConfirm->setEnabled(true);
        sizePolicy2.setHeightForWidth(m_pLineEditCryptoPassConfirm->sizePolicy().hasHeightForWidth());
        m_pLineEditCryptoPassConfirm->setSizePolicy(sizePolicy2);
        m_pLineEditCryptoPassConfirm->setMinimumSize(QSize(200, 0));
        m_pLineEditCryptoPassConfirm->setEchoMode(QLineEdit::Password);

        formLayout_2->setWidget(2, QFormLayout::FieldRole, m_pLineEditCryptoPassConfirm);


        verticalLayout->addLayout(formLayout_2);

        verticalSpacer_4 = new QSpacerItem(20, 100, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_4);

        SetupWizardBase->addPage(m_pCryptoPage);
#ifndef QT_NO_SHORTCUT
        m_pLabel_26->setBuddy(m_pComboCryptoMode);
        m_pLabel_23->setBuddy(m_pLineEditCryptoPass);
        m_pLabel_24->setBuddy(m_pLineEditCryptoPassConfirm);
#endif // QT_NO_SHORTCUT

        retranslateUi(SetupWizardBase);

        QMetaObject::connectSlotsByName(SetupWizardBase);
    } // setupUi

    void retranslateUi(QWizard *SetupWizardBase)
    {
        SetupWizardBase->setWindowTitle(QApplication::translate("SetupWizardBase", "Setup Synergy", 0, QApplication::UnicodeUTF8));
        m_pNodePage->setTitle(QApplication::translate("SetupWizardBase", "Server or Client?", 0, QApplication::UnicodeUTF8));
        m_pNodePage->setSubTitle(QString());
        m_pServerRadioButton->setText(QApplication::translate("SetupWizardBase", "&Server (new setup)", 0, QApplication::UnicodeUTF8));
        m_pClientLabel->setText(QApplication::translate("SetupWizardBase", "This is the first computer you are configuring. Your keyboard and mouse are connected to this computer. This will allow you to move your mouse over to another computer's screen. There can only be one server in your setup.", 0, QApplication::UnicodeUTF8));
        m_pClientRadioButton->setText(QApplication::translate("SetupWizardBase", "&Client (add to setup)", 0, QApplication::UnicodeUTF8));
        m_pServerLabel->setText(QApplication::translate("SetupWizardBase", "You have already set up a server. This is a computer you wish to control using the server's keyboard and mouse. There can be many clients in your setup.", 0, QApplication::UnicodeUTF8));
        m_pCryptoPage->setTitle(QApplication::translate("SetupWizardBase", "Encryption", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("SetupWizardBase", "Network traffic can be easily monitored. Using encryption can reduce the risk that sensitive information will be revealed to others (for example, passwords).", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("SetupWizardBase", "Choose a random encryption mode. The mode must be the same on both the client and server.", 0, QApplication::UnicodeUTF8));
        m_pLabel_26->setText(QApplication::translate("SetupWizardBase", "&Mode:", 0, QApplication::UnicodeUTF8));
        m_pLabel_27->setText(QApplication::translate("SetupWizardBase", "A longer password will provide stronger encryption. It is a good idea to use 20 characters or more.", 0, QApplication::UnicodeUTF8));
        m_pLabel_23->setText(QApplication::translate("SetupWizardBase", "&Password:", 0, QApplication::UnicodeUTF8));
        m_pLabel_24->setText(QApplication::translate("SetupWizardBase", "&Confirm:", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class SetupWizardBase: public Ui_SetupWizardBase {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETUPWIZARDBASE_H
