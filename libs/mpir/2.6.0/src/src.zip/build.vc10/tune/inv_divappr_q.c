#define TUNE_PROGRAM_BUILD 1
#include "..\..\mpn\generic\inv_divappr_q.c"
