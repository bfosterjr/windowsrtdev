#define TUNE_PROGRAM_BUILD 1
#include "..\..\mpn\generic\divrem_hensel_qr_1.c"
