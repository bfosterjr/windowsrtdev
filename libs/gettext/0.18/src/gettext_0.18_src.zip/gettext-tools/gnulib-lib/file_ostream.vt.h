/* DO NOT EDIT! GENERATED AUTOMATICALLY! */

/* Virtual function table layout of superclass.  */
#include "ostream.vt.h"

/* Virtual function table layout of file_ostream class.  */
