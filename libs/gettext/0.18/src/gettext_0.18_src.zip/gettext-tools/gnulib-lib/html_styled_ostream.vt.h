/* DO NOT EDIT! GENERATED AUTOMATICALLY! */

/* Virtual function table layout of superclass.  */
#include "styled_ostream.vt.h"

/* Virtual function table layout of html_styled_ostream class.  */
