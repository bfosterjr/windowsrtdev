This directory contains copies of the scintilla/src and
scintilla/include directories from the Scintilla/SCiTE source
distribution.  All other code needed to implement Scintilla on top of
wxWindows is located in the directory above this one.

The current version of the Scintilla code is 1.70

