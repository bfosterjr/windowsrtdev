/*
This file is distributed in public domain. You can do whatever you want
with its content.
*/
#include <libssh/libssh.h>
int authenticate (SSH_SESSION *session);
SSH_OPTIONS *set_opts(int argc, char **argv);

